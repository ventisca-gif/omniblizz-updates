OmniBlizz Original 1.99.2

Original 1.99.2: adds five independent racial skill trees for Omnitrix, Osmosian, Anodite, System and Bendy. Uses the existing level-up skill points shared with alien and absorption skills. Four ranked passives and one level60 special per race, multilingual UI, persistent ranks/cooldowns and point refunds for coins. Preserves performance improvements and prior content.

Cinco árboles raciales separados. Usan los puntos de habilidad existentes. Cuatro idiomas; guardado y devolución de puntos.
