// Original1.94: working Plumber floor controls and Highbreed portraits.
const pediaBefore198=pediaIcon18;
pediaIcon18=function(canvas,row,known,...args){
 if(row<704||row>706)return pediaBefore198(canvas,row,known,...args);
 if(!canvas)return;
 const im=art197('highbreed'),token={};canvas.pending198=token;
 const paint=()=>{if(canvas.pending198!==token||!canvas.isConnected||!im.naturalWidth)return;const c=canvas.getContext('2d'),size=Math.min(canvas.width-4,canvas.height-4);c.clearRect(0,0,canvas.width,canvas.height);c.imageSmoothingEnabled=false;c.drawImage(im,0,(row-704)*256,256,256,(canvas.width-size)/2,(canvas.height-size)/2,size,size);if(!known){c.globalCompositeOperation='source-in';c.fillStyle='#142434';c.fillRect(0,0,canvas.width,canvas.height);c.globalCompositeOperation='source-over';}};
 paint();if(!im.complete)im.addEventListener('load',paint,{once:true});
};
function floorLabel198(){return zone===BASE196?L196('SUBIR · PISO 2','UP · FLOOR 2','SUBIR · ANDAR 2','ÇIK · KAT 2'):L196('BAJAR · PISO 1','DOWN · FLOOR 1','DESCER · ANDAR 1','İN · KAT 1');}
function changeFloor198(){
 if(!baseHere196()||!started||cinematic||blocked112()||net.role||photon145.joined||raceRun196)return false;
 const target=zone===BASE196?UP196:BASE196;
 closeDialog();resetInput();
 if(!personalEnter47(target,1240,760)){toast(L196('No se pudo cambiar de piso. Inténtalo de nuevo.','Could not change floors. Try again.','Não foi possível mudar de andar. Tente novamente.','Kat değiştirilemedi. Tekrar dene.'));return false;}
 ship134().aboard=false;player.inv=3;cityBounds21();hud();save();return true;
}
const floorButton198=document.createElement('button');floorButton198.id='plumber-floor198';floorButton198.hidden=true;floorButton198.setAttribute('data-no-i18n','');floorButton198.onclick=changeFloor198;$('#hud').append(floorButton198);
const floorStyle198=document.createElement('style');floorStyle198.textContent='#plumber-floor198{position:absolute;left:41%;bottom:34%;width:23%;min-height:44px;padding:9px 5px;z-index:29;color:#e9ffff;background:#103b4e;border:2px solid #7be9ff;border-radius:7px;font:bold clamp(10px,1.2vw,15px) Arial;touch-action:manipulation}#plumber-floor198[hidden]{display:none!important}';document.head.append(floorStyle198);
const interactBefore198=interact;interact=function(...args){if(baseHere196()&&player.x>=1190&&player.y>=620&&player.y<=840)return changeFloor198();return interactBefore198(...args);};
const hudBefore198=hud;hud=function(...args){const r=hudBefore198(...args);floorButton198.hidden=!started||!baseHere196()||!!raceRun196||!!cinematic;if(!floorButton198.hidden){text193(floorButton198,floorLabel198());if(player.x>=1190&&player.y>=620&&player.y<=840)text193($('#talk'),floorLabel198());}return r;};
const drawBefore198=drawScene;drawScene=function(c,z,...args){const r=drawBefore198(c,z,...args);if(baseHere196(z)){c.save();c.fillStyle='#103b4e';c.strokeStyle='#7be9ff';c.lineWidth=3;c.fillRect(1200,720,100,52);c.strokeRect(1200,720,100,52);c.fillStyle='#c4faff';c.font='bold 20px Arial';c.textAlign='center';c.fillText(z===BASE196?'↑ 2':'↓ 1',1250,753);c.restore();}return r;};
// The user requested this movie; enable cutscenes once for existing saves.
if(localStorage.getItem('omni-fasttrack-movie198')!=='1'){cinemaEnabled=true;localStorage.setItem('omni-cinematics','1');localStorage.setItem('omni-fasttrack-movie198','1');}
const movieBefore198=startMovie197;startMovie197=function(){const r=movieBefore198();if(r&&cinematic?.id==='fast197'){cinematic.mode='movie';resetInput();player.watchOpen=false;try{video197.currentTime=0;}catch{}window.OmniMusic?.pauseForEvent();}return r;};
$('#talk').onclick=()=>interact();$('#transform').onclick=()=>transform();
if(location.search.includes('qa=1'))window.__v198={eval:s=>eval(s)};
