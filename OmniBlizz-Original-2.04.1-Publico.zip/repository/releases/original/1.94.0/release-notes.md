OmniBlizz Original 1.94

Original 1.94: Highbreed Omnipedia portraits render directly from the packaged atlas. Visible Plumber floor button and marked landing work in both directions. Supplied Fasttrack transformation video retained byte-identically with audio and double-tap skip; cutscenes enabled once for existing saves. Includes all pending 1.92 and 1.93 content.

No physical Android test or measured FPS guarantee.
