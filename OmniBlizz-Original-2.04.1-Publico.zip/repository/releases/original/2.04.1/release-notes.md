OmniBlizz Original 2.04.1

Original 2.04.1: visible Combat Mastery HUD next to the racial tree. Shows the active or selected form, level 0-300 and EXP to the next level. Tap to open mastery details. Separate race themes and four languages. Mastery progression and combat balance are unchanged.

Cambio rápido exclusivo del Recalibrado desde nivel 150. Dos diales, coste 10, cambio directo y tiempo ralentizado al elegir. Español, English, Português, Türkçe.
