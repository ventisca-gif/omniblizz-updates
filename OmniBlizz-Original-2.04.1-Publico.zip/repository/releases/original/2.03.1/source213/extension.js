// Original 2.03.1: clip the two dial pictures to their circular rim, preserving internal black artwork.
const quickStyle213=document.createElement('style');quickStyle213.textContent='#quickdial212 .quick-art212>img{clip-path:ellipse(47.3% 49% at 50% 49.1%)}';document.head.appendChild(quickStyle213);
