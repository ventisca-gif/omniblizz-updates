OmniBlizz Original 2.03.1

Original 2.03.1: remove rectangular black backgrounds from both quick-switch dials with circular presentation clipping. Dial art, controls, DNA gates and 10-battery switching are unchanged.

Cambio rápido exclusivo del Recalibrado desde nivel 150. Dos diales, coste 10, cambio directo y tiempo ralentizado al elegir. Español, English, Português, Türkçe.
