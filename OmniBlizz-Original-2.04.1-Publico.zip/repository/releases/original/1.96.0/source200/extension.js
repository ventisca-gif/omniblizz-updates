// Original1.96: one HUD transaction per simulation and indexed Anur collision repair.
let simulationDepth200=0,hudDirty200=false,lastHud200=-Infinity,lastKey200='';
const metrics200={hudCalls:0,hudPaints:0,actorCulls:0,indexBuilds:0};
function hudKey200(){return [race,zone,started,paused,dialogOpen,!!cinematic,player.alien,player.selected,player.activeAlien,player.watchOpen,player.form,player.gwenForm51,player.racePower26,attackPage,!!raceRun196,player.hp<=0,OmniI18n.lang].join('|');}
const hudBefore200=hud;
hud=function(...args){metrics200.hudCalls++;if(simulationDepth200){hudDirty200=true;return;}lastHud200=performance.now();lastKey200=hudKey200();metrics200.hudPaints++;return hudBefore200(...args);};
const updateBefore200=update;
update=function(...args){simulationDepth200++;try{return updateBefore200(...args);}finally{if(--simulationDepth200===0&&hudDirty200){hudDirty200=false;const now=performance.now(),key=hudKey200();if(key!==lastKey200||now-lastHud200>=1000/(race==='anodite'?12:15))hud();}}};
// Collision geometry is static on Anur. Keep exact rectangle tests, restrict candidates by cell.
let collisionIndex200=null;
function anurSolid200(x,y,r=16){
 const list=REGIONS[ANUR38].colliders;
 if(!collisionIndex200||collisionIndex200.list!==list||collisionIndex200.length!==list.length){
  const cells=new Map(),size=256;
  for(const b of list)for(let yy=Math.floor(b.y/size);yy<=Math.floor((b.y+b.h)/size);yy++)for(let xx=Math.floor(b.x/size);xx<=Math.floor((b.x+b.w)/size);xx++){const key=xx+','+yy;let cell=cells.get(key);if(!cell)cells.set(key,cell=[]);cell.push(b);}
  collisionIndex200={list,length:list.length,cells,size};metrics200.indexBuilds++;
 }
 const {cells,size}=collisionIndex200;
 for(let yy=Math.floor((y-r)/size);yy<=Math.floor((y+r)/size);yy++)for(let xx=Math.floor((x-r)/size);xx<=Math.floor((x+r)/size);xx++)for(const b of cells.get(xx+','+yy)||[])if(x>b.x-r&&x<b.x+b.w+r&&y>b.y-r&&y<b.y+b.h+r)return true;
 return false;
}
const guideBefore200=target80;target80=function(...args){if(!player.guide78)return null;return guideBefore200(...args);};
// Avoid rewriting the regeneration node four times just to remove an absent legacy suffix.
cleanEchoTimer125=function(){const b=$('#regen'),value=b.textContent,next=value.replace(/(?: · (?:CONEXIÓN|LINK|CONEXÃO|BAĞLANTI) \d+s)+/g,'');if(next!==value)b.textContent=next;};
function actorVisible200(a,cx,cy,zoom){if(a.kind==='player')return true;const o=a.kind==='npc'?npc:a.e;if(!o||!Number.isFinite(o.x)||!Number.isFinite(o.y))return true;const margin=Math.max(700,Number(o.w)||0,Number(o.h)||0);const visible=o.x+margin>=cx&&o.x-margin<=cx+W/zoom&&o.y+margin>=cy&&o.y-margin<=cy+H/zoom;if(!visible)metrics200.actorCulls++;return visible;}
if(location.search.includes('qa=1'))window.__v200={eval:s=>eval(s),metrics:metrics200};
