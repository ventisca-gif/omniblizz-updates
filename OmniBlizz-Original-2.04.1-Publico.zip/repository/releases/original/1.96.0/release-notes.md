OmniBlizz Original 1.96

Original 1.96: performance repair across all races. Coalesces the entire HUD chain once per simulation batch; indexes exact Anur collision checks; skips distant actor rendering while preserving simulation; updates cooldown arrays in place; avoids a duplicate save snapshot and inactive route construction. Includes Highbreed/Tetrax repair and all previous content. Automated audit: 139 zones, 49 alien definitions, 12 Osmosian forms, 7 races and 267 attack cases. Desktop CPU measurements are not a physical Android FPS guarantee.

No physical Android test or measured FPS guarantee.
