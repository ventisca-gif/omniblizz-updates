OmniBlizz Original 2.03.0

Original 2.03.0: Recalibrated Omnitrix quick switch at level 150 while transformed. Two supplied dials, 10 battery per direct alien switch, slow single-player selection, DNA gates and four languages. Existing human selector and revert controls preserved.

Cambio rápido exclusivo del Recalibrado desde nivel 150. Dos diales, coste 10, cambio directo y tiempo ralentizado al elegir. Español, English, Português, Türkçe.
