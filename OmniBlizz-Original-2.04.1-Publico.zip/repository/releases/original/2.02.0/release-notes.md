OmniBlizz Original 2.02.0

Original 2.02.0: Rojo-only route reset, connected Ruins continuation and Toriel home. Puzzles, dialogue, monster encounters, species EXP, nonlethal mercy, inventory and checkpoints. Pacifist, neutral and genocide decisions for the Ruins chapter. Four languages and cloud-compatible independent progress.

Rojo: reiniciar ruta, continuar por las Ruinas, hogar de Toriel y decisiones persistentes. Español, English, Português, Türkçe.
