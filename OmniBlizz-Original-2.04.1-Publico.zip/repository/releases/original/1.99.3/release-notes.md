OmniBlizz Original 1.99.3

Original 1.99.3: adds a separate, selected single-use Omnitrix level50 recovery option inside Test Access. Restores only missing levels and normal shared skill points; preserves other races and existing skills. Server-side atomic redemption, completed-use blocking, durable local save and four languages. Does not grant full test access.

Recuperación autorizada de un solo uso: Omnitrix nivel 50 y puntos normales. Disponible dentro de Acceso de prueba.
