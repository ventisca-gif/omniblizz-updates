// Original1.99.3: selected one-time Omnitrix level50 recovery, separate from full test access.
const RECOVERY_DIGEST206='a073d1ac516a073d11d33690712b40e3825d30ce21bf9ebe9ec6c4e7cdb01388';
let recoveryBusy206=false;
function recoveryEligible206(code){const n=normalizeCode55(code);return /^[A-F0-9]{32}$/.test(n)&&shaFallback55('omniblizz-recovery206:'+n)===RECOVERY_DIGEST206;}
function recoveryTarget206(){return race==='omni'?player:profiles.omni?.player;}
function applyRecovery206(receipt){
 if(!/^[a-f0-9]{64}$/.test(receipt||''))return 'network';
 if(localStorage.getItem('omni-recovered206')||recoveryTarget206()?.recovery206)return 'already';
 if(window.omniRestoring63||localStorage.getItem('omni-pending-restore63'))return 'menu';
 const before=localStorage.getItem(STORE),oldProfiles=cleanClone(profiles),oldPlayer=cleanClone(player);
 try{
  if(!localStorage.getItem('omni-before-recovery206'))localStorage.setItem('omni-before-recovery206',JSON.stringify({save:before,time:Date.now()}));
  if(race!=='omni'&&!profiles.omni){profiles.omni=freshProfile();profiles.omni.player.selected=profiles.omni.player.activeAlien='heatblast';}
  const p=recoveryTarget206(),level=Math.max(1,Math.floor(Number(p.level)||1)),gain=Math.max(0,50-level);
  p.level=Math.max(level,50);if(gain){p.points=Math.max(0,Number(p.points)||0)+gain;p.xp=0;}p.recovery206={grant:'omni-level50-206',receipt,level:50};
  if(race==='omni'){initProgress();player.hp=maxHP();}
  persistGame();const saved=JSON.parse(localStorage.getItem(STORE)||'null'),target=saved?.race==='omni'?saved.player:saved?.profiles?.omni?.player;
  if(target?.recovery206?.receipt!==receipt||target.level<50)throw Error('save');
  localStorage.setItem('omni-recovered206',receipt);return 'ok';
 }catch{
  // A successfully written save itself is the durable redemption marker.
  try{const s=JSON.parse(localStorage.getItem(STORE)||'null'),p=s?.race==='omni'?s.player:s?.profiles?.omni?.player;if(p?.recovery206?.receipt===receipt&&p.level>=50)return 'ok';}catch{}
  profiles=oldProfiles;Object.keys(player).forEach(k=>delete player[k]);Object.assign(player,oldPlayer);return 'storage';
 }
}
async function recoveryAccess206(input){
 if(STORE!=='omni-forest-v1'||!recoveryEligible206(input))return 'denied';
 if(started||net.role||photon145.joined)return 'menu';if(recoveryBusy206)return 'busy';
 if(localStorage.getItem('omni-recovered206')||recoveryTarget206()?.recovery206)return 'already';
 if(window.omniMode61!=='online')return 'offline';
 recoveryBusy206=true;
 try{
  const installation=install204(),token=await token55(input),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);let response,data;
  try{response=await fetch('https://omniblizz-online93.ventisca.chatgpt.site/api/recovery206',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({installation}),cache:'no-store',signal:controller.signal});data=await response.json();}finally{clearTimeout(timer);}
  if(response.status===409)return 'used';if(response.status===403)return 'denied';
  if(!response.ok||data.ok!==true||data.grant!=='omni-level50-206'||data.level!==50||data.race!=='omni')return 'network';
  if(started||net.role||photon145.joined)return 'menu';const result=applyRecovery206(data.receipt);
  if(result==='ok'){
   // Ack is optional for retries: the saved profile already prevents another local application.
   try{await fetch('https://omniblizz-online93.ventisca.chatgpt.site/api/recovery206',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({installation,action:'complete',receipt:data.receipt}),cache:'no-store',signal:AbortSignal.timeout(5000)});}catch{}
  }return result;
 }catch{return 'network';}finally{recoveryBusy206=false;}
}
function recoveryMenu206(){showDialog(L203('RECUPERAR NIVEL 50','RECOVER LEVEL 50','RECUPERAR NÍVEL 50','50. SEVİYEYİ KURTAR'),L203('Solo Omnitrix · un uso','Omnitrix only · one use','Só Omnitrix · uso único','Yalnız Omnitrix · tek kullanım'),'<div data-no-i18n><p>'+L203('Solo el código autorizado recupera la raza Omnitrix hasta nivel 50 y sus puntos normales de nivel. No concede acceso completo de pruebas. Conserva las otras razas y las habilidades que ya tengas. Si superas nivel 50 no baja tu nivel. Necesitas internet.','Only the authorized code restores the Omnitrix race to level 50 and its normal level-up points. It does not grant full test access. Other races and existing skills are preserved. Levels above 50 are not reduced. Internet is required.','Só o código autorizado recupera a raça Omnitrix até nível 50 e seus pontos normais. Não concede acesso completo de testes. Preserva outras raças e habilidades existentes. Níveis acima de 50 não diminuem. Requer internet.','Yalnız yetkili kod Omnitrix ırkını normal seviye puanlarıyla 50. seviyeye getirir. Tam test erişimi vermez. Diğer ırklar ve beceriler korunur. 50 üstü seviye düşmez. İnternet gerekir.')+'</p><label>'+L203('Código autorizado','Authorized code','Código autorizado','Yetkili kod')+'<input id="recovery-input206" type="password" autocomplete="off" spellcheck="false" maxlength="48" style="display:block;width:92%;padding:12px;font:16px monospace"></label><p id="recovery-status206" role="status"></p></div>',[[L203('RECUPERAR NIVEL 50','RECOVER LEVEL 50','RECUPERAR NÍVEL 50','50. SEVİYEYİ KURTAR'),async()=>{if(recoveryBusy206)return;const f=$('#recovery-input206'),status=$('#recovery-status206'),code=f.value;f.value='';status.textContent=L203('Verificando…','Checking…','Verificando…','Kontrol ediliyor…');const r=await recoveryAccess206(code);if(!status.isConnected)return;status.textContent=r==='ok'?L203('Omnitrix recuperado: nivel 50 como mínimo. Este acceso ya fue utilizado.','Omnitrix restored to at least level 50. This access has been used.','Omnitrix recuperado: nível mínimo 50. Este acesso já foi utilizado.','Omnitrix en az 50. seviyeye kurtarıldı. Bu erişim kullanıldı.'):r==='already'||r==='used'?L203('Este acceso de recuperación ya fue utilizado.','This recovery access has already been used.','Este acesso de recuperação já foi utilizado.','Bu kurtarma erişimi zaten kullanıldı.'):r==='denied'?L203('Código no autorizado.','Unauthorized code.','Código não autorizado.','Yetkisiz kod.'):r==='offline'?L203('Inicia en modo en línea para recuperar.','Start in online mode to recover.','Inicie no modo online para recuperar.','Kurtarmak için çevrimiçi başlat.'):r==='menu'?L203('Úsalo desde el menú principal, fuera de una sala.','Use from the main menu, outside a room.','Use no menu principal, fora de uma sala.','Ana menüde, oda dışında kullan.'):L203('No se pudo guardar. Revisa internet y espacio; reintenta en esta instalación.','Could not save. Check internet and space; retry on this installation.','Não foi possível salvar. Verifique internet e espaço; tente nesta instalação.','Kaydedilemedi. İnterneti ve alanı kontrol edip bu kurulumda yeniden dene.');}],[L203('VOLVER','BACK','VOLTAR','GERİ'),()=>testerMenu203()]]);}
const menuBefore206=testerMenu203;testerMenu203=function(){menuBefore206();const b=document.createElement('button');b.setAttribute('data-no-i18n','');b.textContent=L203('RECUPERAR NIVEL 50','RECOVER LEVEL 50','RECUPERAR NÍVEL 50','50. SEVİYEYİ KURTAR');b.onclick=recoveryMenu206;$('#dialogbuttons').appendChild(b);};
if(STORE==='omni-forest-v1')$('#tester-access203').onclick=()=>testerMenu203();
if(location.search.includes('qa=1'))window.__v206={eval:s=>eval(s),recoveryAccess206,applyRecovery206,recoveryMenu206};
