OmniBlizz Original 2.00.1

Original 2.00.1: Undertale Rojo opening chapter with a corrected walkable flower bed. Reference selection, four-direction walking, connected ruins, orange introduction, Flowey tutorial and independent red-soul combat, LV and cloud progress. Preserves all previous races and content.

Rojo: apertura de Undertale con las flores decorativas transitables. Caminos conectados, combate del corazón y guardado independiente.
