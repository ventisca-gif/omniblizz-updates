OmniBlizz Original1.90

Original1.92: Omnipedia y registros corregidos, autoaim Sistema sin ampliar alcances, regalo único de10 puntos Omnitrix. Base Plomera de dos pisos, Max AF y reputación con misiones planetarias inactivas. Helen Wheels y carrera para desbloquear Fasttrack:1450HP, puño100, supervelocidad, patadas210, giro215, cuatro tornados220 e intangibilidad5s con carga cinética. / Fixed encyclopedia, System autoaim, once-only10 Omnitrix points. Two-floor Plumber base, Max AF, inactive reputation missions, Helen race and Fasttrack.

136maps,48alien definitions,12Osmosian forms and10video files preserved. No physical Android FPS claim.
