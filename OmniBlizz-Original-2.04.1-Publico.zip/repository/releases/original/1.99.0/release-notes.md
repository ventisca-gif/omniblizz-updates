OmniBlizz Original 1.99

Original 1.99: fixes Fasttrack locked silhouettes and unlocked bestiary portraits. The phone mission app now lists active NPC missions and progress in Spanish, English, Portuguese and Turkish, excluding Saiyan and Ash. Adds optional test access for one allowlisted recovery identity; the input must match the current save identity. Ordinary players retain normal progression. Preserves the 1.98 rendering improvements.

Registro de misiones traducido; Fasttrack corregido; acceso de pruebas opcional para una sola identidad. El código privado no se incluye en las notas ni en los archivos públicos.
