// Original1.99: Fasttrack bestiary, active mission journal and one allowlisted tester.
const L203=(...s)=>L148(...s),esc203=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fastBounds203=new WeakMap();
function fastIcon203(canvas,known){
 if(!canvas)return;const im=art197('fastwalk');
 const paint=()=>{if(!canvas.isConnected||!im.complete||!im.naturalWidth)return;let b=fastBounds203.get(im);
  if(!b){const tile=document.createElement('canvas');tile.width=tile.height=256;const t=tile.getContext('2d',{willReadFrequently:true});t.drawImage(im,0,0,256,256,0,0,256,256);const pixels=t.getImageData(0,0,256,256).data;let x0=256,y0=256,x1=-1,y1=-1;for(let y=0;y<256;y++)for(let x=0;x<256;x++)if(pixels[(y*256+x)*4+3]>8){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}if(x1<0)return;b=[Math.max(0,x0-2),Math.max(0,y0-2),Math.min(256,x1+3)-Math.max(0,x0-2),Math.min(256,y1+3)-Math.max(0,y0-2)];fastBounds203.set(im,b);}
  const c=canvas.getContext('2d'),scale=Math.min((canvas.width-6)/b[2],(canvas.height-6)/b[3]);c.save();c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,canvas.width,canvas.height);c.globalAlpha=1;c.globalCompositeOperation='source-over';c.imageSmoothingEnabled=false;c.drawImage(im,...b,(canvas.width-b[2]*scale)/2,(canvas.height-b[3]*scale)/2,b[2]*scale,b[3]*scale);if(!known){c.globalCompositeOperation='source-in';c.fillStyle='#000';c.fillRect(0,0,canvas.width,canvas.height);}c.restore();
 };paint();if(!im.complete)im.addEventListener('load',paint,{once:true});
}
const iconBefore203=pediaIcon18;pediaIcon18=function(canvas,row,known,...a){return row===FASTROW196?fastIcon203(canvas,known):iconBefore203(canvas,row,known,...a);};
const pediaBefore203=omnipedia17;omnipedia17=function(tab='aliens',...a){const out=pediaBefore203(tab,...a);if(tab==='aliens'){const b=document.querySelector('[data-entry18="'+FAST196+'"]');if(b){let c=b.querySelector('canvas');if(!c){b.querySelector('img')?.remove();c=document.createElement('canvas');c.width=80;c.height=90;b.prepend(c);}const owner=race==='omni'?player:profiles.omni?.player;fastIcon203(c,!!owner?.plumber196?.fasttrack);}}return out;};

const missionNames203={
 arena102:['Max · desafío de 100 rondas','Max · 100-round challenge','Max · desafio de 100 rodadas','Max · 100 tur mücadelesi'],
 kevin31:['Kevin · entrenamiento osmosiano','Kevin · Osmosian training','Kevin · treino osmosiano','Kevin · Osmosyalı eğitimi'],
 quest:['Max · patrulla del Refugio','Max · Refuge patrol','Max · patrulha do Refúgio','Max · Sığınak devriyesi'],
 knightQuest:['Caballero de la Eternidad','Knight of Eternity','Cavaleiro da Eternidade','Sonsuzluk Şövalyesi'],
 story:['Ten · Fuerza Galáctica','Ten · Galactic Force','Ten · Força Galáctica','Ten · Galaktik Güç'],story2:['Ten · Dr. Ánimo','Ten · Dr. Animo','Ten · Dr. Animal','Ten · Dr. Animo'],story3:['Ten · magia y sombras','Ten · magic and shadows','Ten · magia e sombras','Ten · büyü ve gölgeler'],
 clancy21:['Clancy · Bellwood','Clancy · Bellwood','Clancy · Bellwood','Clancy · Bellwood'],phill25:['Phill · entrenamiento','Phill · training','Phill · treinamento','Phill · eğitim'],mine25:['La mina · ADN de momia','The mine · mummy DNA','A mina · DNA de múmia','Maden · mumya DNA’sı'],kai28:['Kai · investigación','Kai · investigation','Kai · investigação','Kai · araştırma'],forest35:['Agente · bosque lunar','Agent · Moon Forest','Agente · Floresta da Lua','Ajan · Ay Ormanı'],ultraQuest38:['Plomeros · Ultradrón','Plumbers · Ultradron','Encanadores · Ultradrone','Tesisatçılar · Ultradrone'],stormQuest47:['Dr. Viktor · el Conductor','Dr. Viktor · the Conductor','Dr. Viktor · o Condutor','Dr. Viktor · İletken'],vilgax53:['Ten · Vilgax','Ten · Vilgax','Ten · Vilgax','Ten · Vilgax'],tick56:['La gran garrapata','The Big Tick','O Grande Carrapato','Büyük Kene'],worshipQuest58:['Guardián · culto','Keeper · cult','Guardião · culto','Muhafız · tarikat'],limax78:['Los Limax','The Limax','Os Limax','Limax'],diamondQuest51:['Diamante · entrenamiento','Diamondhead · training','Diamante · treinamento','Elmas Kafa · eğitim'],techQuest62:['Tecnología · entrenamiento','Technology · training','Tecnologia · treinamento','Teknoloji · eğitim'],eyeQuest62:['Multi Ojo · investigación','Eye Guy · investigation','Multiolhos · investigação','Göz Adam · araştırma'],patrol155:['Informante · Xenocites','Informant · Xenocites','Informante · Xenocites','Muhbir · Xenocite'],patrol158:['Monkey · contrabando','Monkey · smuggling','Monkey · contrabando','Monkey · kaçakçılık'],storyAF158:['Ten AF · el regreso','Ten AF · the return','Ten AF · o retorno','Ten AF · dönüş']
};
function missionTitle203(path){const key=path.split('.').pop();if(missionNames203[key])return L203(...missionNames203[key]);if(path.startsWith('chapters80.')){const d=CHAPTERS80[key]||DEFS83[key];if(d?.names)return L203(...d.names);if(key==='kevin')return 'Kevin 11';}return L203('Misión adicional','Additional mission','Missão adicional','Ek görev');}
function activeMissions203(){
 if(race===SAI167||race===POKE177)return[];const found=[],seen=new Set(),inactive=new Set(['new','idle','inactive','locked','complete','completed','done','none','unstarted','off','failed']);
 const add=(path,q,state)=>{if(!q||seen.has(path))return;seen.add(path);const ready=['done','return','ready','reward'].includes(state),parts=[];if(q.kills!==undefined){const n=Array.isArray(q.kills)?q.kills.length:Number(q.kills);if(Number.isFinite(n))parts.push(L203('Derrotados','Defeated','Derrotados','Yenilen')+': '+n+(Number.isFinite(q.goal)?' / '+q.goal:path==='quest'?' / 7':''));}if(Number.isFinite(q.round))parts.push(L203('Ronda','Round','Rodada','Tur')+': '+q.round);if(Number.isFinite(q.stage))parts.push(L203('Etapa','Stage','Etapa','Aşama')+': '+q.stage);if(Array.isArray(q.seen))parts.push(L203('Objetivos','Objectives','Objetivos','Hedefler')+': '+q.seen.length);found.push({id:path,title:missionTitle203(path),ready,progress:parts.join(' · ')});};
 add('quest',quest,quest?.state);if(inactive.has(quest?.state)||!quest?.state)found.length=0;
 const visit=(obj,path='',depth=0)=>{if(!obj||typeof obj!=='object'||Array.isArray(obj)||depth>5)return;for(const key of Object.keys(obj)){if(['zoneStates','civilStates','bestiary','profiles','inventory','masteries','cooldowns','origin','checkpoint','snapshot','backup','previous','receipts'].includes(key))continue;const q=obj[key],p=path?path+'.'+key:key;if(!q||typeof q!=='object'||Array.isArray(q))continue;const named=!!missionNames203[key]||/quest|story|chapter|mission|patrol|vilgax|tick|limax|expedition|dungeon|trial/i.test(p);if(named&&typeof q.state==='string'&&!inactive.has(q.state))add(p,q,q.state);else if(named&&(q.active===true||q.started===true)&&q.completed!==true)add(p,q,'active');visit(q,p,depth+1);}};visit(player);
 const af=player.storyAF158;if(af&&!af.claimed&&af.stage>0&&af.stage<7)add('storyAF158',af,af.stage>=5?'return':'active');
 const m=player.plumber196?.mission197;if(m&&['earth','anur','petropia'].includes(m.planet)){const id='plumber196.mission197';if(!seen.has(id)){add(id,m,m.kills>=m.goal?'return':'active');const row=found.find(v=>v.id===id);if(row)row.title='Max AF · Highbreed · '+planetName197(m.planet);}}
 const daily=player.system148?.quest151;if(race===SYSTEM148&&daily&&!daily.claimed&&Number.isFinite(daily.next)&&daily.next>Date.now())found.push({id:'system148.quest151',title:L203('Sistema · entrenamiento','System · training','Sistema · treinamento','Sistem · eğitim'),ready:daily.hits>=20&&daily.kills>=5,progress:L203('Aciertos','Hits','Acertos','İsabetler')+': '+Math.min(20,daily.hits||0)+'/20 · '+L203('Derrotados','Defeated','Derrotados','Yenilen')+': '+Math.min(5,daily.kills||0)+'/5'});
 if(expedition104?.active)found.push({id:'expedition104',title:L203('Expedición · Vacío Nulo','Expedition · Null Void','Expedição · Vácuo Nulo','Keşif · Hiçlik'),ready:false,progress:L203('Ronda','Round','Rodada','Tur')+': '+expedition104.round});
 return found;
}
function missionJournal203(){if(race===SAI167||race===POKE177)return false;const rows=activeMissions203();showDialog(L203('TELÉFONO · MISIONES','PHONE · MISSIONS','TELEFONE · MISSÕES','TELEFON · GÖREVLER'),L203('Misiones activas','Active missions','Missões ativas','Etkin görevler'),'<div data-no-i18n class="mission-list203">'+(rows.length?rows.map(q=>'<article><h3>'+esc203(q.title)+'</h3><b>'+esc203(q.ready?L203('LISTA PARA ENTREGAR','READY TO TURN IN','PRONTA PARA ENTREGAR','TESLİME HAZIR'):L203('EN CURSO','IN PROGRESS','EM ANDAMENTO','DEVAM EDİYOR'))+'</b><p>'+esc203(q.progress||L203('Continúa el objetivo de esta misión y regresa con el NPC.','Continue this mission’s objective and return to the NPC.','Continue o objetivo desta missão e volte ao NPC.','Bu görevin hedefini tamamlayıp NPC’ye dön.'))+'</p></article>').join(''):'<p>'+L203('No tienes misiones activas en esta raza. Habla con un NPC para aceptar una.','You have no active missions for this race. Talk to an NPC to accept one.','Você não tem missões ativas nesta raça. Fale com um NPC para aceitar uma.','Bu ırkta etkin görevin yok. Bir görev almak için NPC ile konuş.')+'</p>')+'</div>',[[L203('ACTUALIZAR','REFRESH','ATUALIZAR','YENİLE'),missionJournal203],[L203('VOLVER AL TELÉFONO','BACK TO PHONE','VOLTAR AO TELEFONE','TELEFONA DÖN'),()=>{closeDialog();openPhone105();}],[L203('CERRAR','CLOSE','FECHAR','KAPAT'),closeDialog]]);return true;}
const appsBefore203=phoneApps105;phoneApps105=function(){const apps=appsBefore203();if(race===SAI167||race===POKE177)return apps.filter(a=>a[0]!=='missions');let included=false;return apps.map(a=>{if(a[0]!=='missions')return a;included=true;return ['missions',['Misiones','Missions','Missões','Görevler'],missionJournal203];}).concat(included?[]:[['missions',['Misiones','Missions','Missões','Görevler'],missionJournal203]]);};
const journalStyle203=document.createElement('style');journalStyle203.textContent='.mission-list203{display:grid;gap:10px;max-height:54vh;overflow-y:auto;touch-action:pan-y}.mission-list203 article{padding:12px;border:1px solid #81b95b;background:#10242bcc}.mission-list203 h3{margin:0 0 6px}.mission-list203 b{font-size:12px;color:#caff8a}.mission-list203 p{margin:6px 0}#tester-access203{position:static!important;min-height:44px;white-space:normal}';document.head.appendChild(journalStyle203);

// This domain-separated digest is not the recovery service token.
const TESTER_DIGEST203='1da6a144047bdedf3f4c96c31dd64f68913af34069f2bdcdafbea1e7009bbb20';let testerEnabled203=false,testerIdentity203='';
function testerAllowed203(){return STORE==='omni-forest-v1'&&testerEnabled203&&normalizeCode55(recoveryCode55)===testerIdentity203;}
function testerIdentityAllowed203(code){const n=normalizeCode55(code);return /^[A-F0-9]{32}$/.test(n)&&shaFallback55('omniblizz-tester203:'+n)===TESTER_DIGEST203;}
if(STORE==='omni-forest-v1'&&testerIdentityAllowed203(recoveryCode55)&&localStorage.getItem('omni-tester203')===TESTER_DIGEST203){testerEnabled203=true;testerIdentity203=normalizeCode55(recoveryCode55);}
// Authorized grant implementation is inserted here at build time.
function testerEligible186(id=race){return testerAllowed203()&&['omni','osmo','bendy','anodite','system148'].includes(id);}
function testerMoney186(p=player){Object.defineProperty(p,'coins',{configurable:true,enumerable:true,get:()=>1000000000,set:()=>{}});}
function grantTester186(){
 if(!testerEligible186())return false;
 const p=player,first=!p.testerGranted92; if(!p.testerGranted97){p.points=Math.max(0,Number(p.points)||0)+(p.testerGranted92?30:0);p.testerGranted97=true;}
 p.level=MAX_LEVEL25;p.xp=0;p.upchuckDNA106=true;p.nullGuardianDNA104=true;
 if(first){p.coins=9999;p.points=99;p.vitality=0;}
 for(const key of ['dnaFire','wildDNA','wolfDNA','ghostDNA','cannonDNA','mummyDNA25','benvictorDNA38','corrosionDNA45','dittoDNA47','eyeDNA62','gwenUnlocked51'])p[key]=true;
 p.absorbUnlocks=Object.assign(p.absorbUnlocks||{},Object.fromEntries(Object.keys(OSMO_FORMS).map(k=>[k,true])));
 for(const [id,a]of Object.entries(ALIENS)){p.masteries[id]=masteryCaps174.has(id)?200:100;p.learned[id]=Array(Math.max(0,a.skills.length-4)).fill(true);}
 p.unlockedAlienSkins=Object.assign(p.unlockedAlienSkins||{},{fourarmsConcert:true,ghostLady:true,pinkFire:true,xlrNocturne:true,wildMoon:true,ultraAnime:true,dittoFemale58:true});
 p.kevin31.unlocked=true;p.kevin31.wins=Math.max(5,p.kevin31.wins);p.kevin31.seconds=1200;
 p.diamondQuest51.unlocked=true;p.diamondQuest51.wins=Math.max(2,p.diamondQuest51.wins);
 p.techQuest62.unlocked=true;p.eyeQuest62.unlocked=true;p.prototype87.unlocked=true;
 p.nuclear.acid=true;p.nuclear.gate=true;
 // Unlock chapter replay and the earned Omnitrix capacity without starting a quest.
 if(first){
  for(const q of [p.story,p.story2,p.story3])Object.assign(q,{state:'complete',rewarded21:true,completions21:1,reward:0});
  p.story.completions=2;p.clancy21.state='complete';p.clancy21.completions=1;p.clancy21.rewarded=true;
  Object.assign(p.vilgax53,{state:'complete',completed:true,rewarded:true,xpReward56:true});
  p.warps=REGIONS.map((_,i)=>i).filter(i=>!saiZone167(i)&&!pokeZone177(i)&&![20,21,22].includes(i));
  p.inventory28.suit=1;p.inventory28.sixsix=1;p.inventory28.medkit=99;p.inventory28.energy=99;
 }
 p.omniCapacity53=race==='omni'?150:100;
 p.ownedWatches73=Object.keys(WATCHES73);
 if(first&&race==='omni')p.equippedWatch73='original';if(race==='omni'&&!p.testerRecal115){p.testerRecal115=true;p.equippedWatch73='recalibrated115';p.selected=SWAMP115;p.alien=false;p.battery=200;}
 p.formRecords=Object.assign(p.formRecords||{},Object.fromEntries(Object.keys(OSMO_FORMS).map(k=>[k,true])));
 p.bestiary=p.bestiary||{};
 for(const id of Object.keys(BESTIARY18))p.bestiary[id]=Object.assign({level:70,hp:100,zone:1,scanned54:true},p.bestiary[id]||{});
 discovered=Array.from(new Set([...discovered,...REGIONS.filter((_,i)=>!saiZone167(i)&&!pokeZone177(i)).map(r=>r.id)]));
 opened=Array.from(new Set([...opened,...REGIONS.filter((_,i)=>!saiZone167(i)&&!pokeZone177(i)).map(r=>r.id)]));
 p.testerGranted92=true;p.testerEdition92=true;
 if(first){p.battery=omniCap53();p.raceResource26=100;p.hp=maxHP();}
}
function testerExtras186(){
 if(!testerEligible186())return;
 const p=player;testerMoney186();if(race==='anodite'){const s=anodState187();s.ranks=[5,5,5,5,5];}p.points=Math.max(999,Number(p.points)||0);
 for(const [id,a] of Object.entries(ALIENS)){p.masteries[id]=masteryCaps174.has(id)?200:100;p.learned[id]=a.skills.slice(4).map(()=>true);}
 p.masteryArchive174={...p.masteries};p.seenHum130=p.seenMono137=p.wayDNA130=true;
 p.halloween87={...(p.halloween87||{}),candies:1000000000,fireRider:true,benghost:true,revision:Date.now()};
 const pet=companions113();pet.ship.owned=true;pet.ship.level=5;pet.ship.xp=0;pet.mount.owned=true;
 ship134().owned=true;const home=house97();home.owned=true;home.expansion=3;
 if(!p.tester186Inventory){home.inventory=[...new Set([...home.inventory,...Object.keys(furniture97)])].slice(0,200);p.tester186Inventory=true;}
 p.clothesOwned104={...(p.clothesOwned104||{})};for(const list of Object.values(outfits100))for(const item of list)if(item.key104)p.clothesOwned104[item.key104]=true;
 if(p.casino)Object.defineProperty(p.casino,'chips',{configurable:true,enumerable:true,get:()=>1000000000,set:()=>{}});
 if(race===SYSTEM148){
  const s=data148();s.stage=5;s.free=Math.max(999,s.free);s.weapon='dagger';
  const gear=['head','armor','hands','feet','ring','neck'].map(k=>'gear151-'+k+'-12');
  s.inventory=[...new Set([...s.inventory,...Object.keys(weapons149),'potion','armor',...gear])].slice(0,96);
  for(const k of ['head','armor','hands','feet','ring','neck'])s.equipment[k]='gear151-'+k+'-12';s.equipment.weapon='ember151';s.extraOff151=[];s.mana=manaMax148();
  const n=state153();n.job='necro';n.skills=[0,1,2,3,4,5];
  if(!n.shadows.some(q=>q.igris149))n.shadows.push({id:'tester-igris186',name:'Igris',baseHP:8000,baseDamage:70,level:200,row:348,igris149:true});
  for(const q of n.shadows){q.soldierLevel153=40;q.soldierXP153=0;q.rank154=5;n.health152[q.id]=1;}
  if(!n.equipped.length)n.equipped=n.shadows.slice(0,armyLimit153()).map(q=>q.id);
  if(zone===TEMPLE148){zone=1;p.x=540;p.y=627;enemies=zoneStates[region().id]||[];}
 }
}

function grantNative203(){if(!testerAllowed203())return;if(race===SAI167){const n=saiState167();Object.assign(n,{power:1e12,body:100,breath:100,roshi:3,lesson:20,kame:true,kiBlast:true,zenkai:20});Object.assign(otherState172(),{stage:4,mastery:1800,genki:true,raditzAfter:true,arrival:true});namekState186().potential=true;return;}if(race===POKE177){const n=pokeState177();if(!player.testerPokemon203){for(const id of Object.keys(pokeDefs177))if(![...n.party,...n.box].some(q=>q.id===id)){const q=pokeNew177(id,60,n);if(n.party.length<4)n.party.push(q);else if(n.box.length<30)n.box.push(q);}for(const q of [...n.party,...n.box]){q.level=60;q.xp=0;q.ivs=Object.fromEntries(pKeys179.map(k=>[k,31]));q.quality='great';q.hp=pokeStats177(q.id,60,q).hp;q.energy=100;q.pp=pokeDefs177[q.id].moves.map(m=>m[5]);}n.items.potion=n.items.pokeball=999;n.seen=n.caught=Object.keys(pokeDefs177);player.testerPokemon203=true;}return;}}
function grantTester203(){if(!testerAllowed203())return false;if([SAI167,POKE177].includes(race)){grantNative203();return true;}grantTester186();testerExtras186();const p=plumbState196();p.joined=true;p.fasttrack=true;p.reputation=Math.max(10000,p.reputation);player.points=Math.max(999,player.points||0);return true;}
const initBefore203=initProgress;initProgress=function(...args){const out=initBefore203(...args);grantTester203();return out;};
function activateTester203(input){if(STORE!=='omni-forest-v1'||!testerIdentityAllowed203(input))return 'denied';if(normalizeCode55(input)!==normalizeCode55(recoveryCode55))return 'identity';if(net.role||photon145.joined||started)return 'menu';if(!testerAllowed203()){if(!localStorage.getItem('omni-before-tester203'))localStorage.setItem('omni-before-tester203',JSON.stringify({save:localStorage.getItem(STORE),time:Date.now()}));testerIdentity203=normalizeCode55(recoveryCode55);testerEnabled203=true;localStorage.setItem('omni-tester203',TESTER_DIGEST203);}grantTester203();persistGame();return 'ok';}
const activateBefore203=activateTester203;activateTester203=function(input){
 const before=profileSnapshot(),enabled=testerEnabled203,identity=testerIdentity203,flag=localStorage.getItem('omni-tester203'),set=Storage.prototype.setItem;let written=false;
 try{Storage.prototype.setItem=function(k,v){const r=set.call(this,k,v);if(k===STORE)written=true;return r;};const result=activateBefore203(input);if(result==='ok'&&!written)throw Error('save');return result;}
 catch{testerEnabled203=enabled;testerIdentity203=identity;try{if(flag===null)localStorage.removeItem('omni-tester203');else set.call(localStorage,'omni-tester203',flag);applyProfile(before);}catch{}return 'error';}
 finally{Storage.prototype.setItem=set;}
};
function testerMenu203(){showDialog(L203('ACCESO DE PRUEBA','TEST ACCESS','ACESSO DE TESTE','TEST ERİŞİMİ'),L203('Jugador autorizado','Authorized player','Jogador autorizado','Yetkili oyuncu'),'<div data-no-i18n><p>'+L203('Solo está habilitado para el código de respaldo autorizado y su partida actual. Si cambiaste de dispositivo, restaura primero esa partida. Se conserva una copia local antes de aplicar los desbloqueos.','Only the authorized recovery code and its current save are eligible. On a new device, restore that save first. A local copy is kept before applying unlocks.','Disponível apenas para o código de recuperação autorizado e sua partida atual. Em outro aparelho, restaure essa partida primeiro. Uma cópia local é guardada antes dos desbloqueios.','Yalnız yetkili kurtarma kodu ve ona ait mevcut kayıt uygundur. Yeni cihazda önce o kaydı geri yükle. Kilitler açılmadan önce yerel bir kopya saklanır.')+'</p><label>'+L203('Código de respaldo','Recovery code','Código de recuperação','Kurtarma kodu')+'<input id="tester-input203" type="password" autocomplete="off" spellcheck="false" maxlength="48" style="display:block;width:92%;padding:12px;font:16px monospace"></label><p id="tester-status203" role="status"></p></div>',[[L203('ACTIVAR PRUEBAS','ACTIVATE TESTING','ATIVAR TESTES','TESTİ ETKİNLEŞTİR'),()=>{const result=activateTester203($('#tester-input203').value);$('#tester-input203').value='';$('#tester-status203').textContent=result==='ok'?L203('Acceso activado. Las razas recibirán sus desbloqueos al seleccionarlas.','Access activated. Each race receives its unlocks when selected.','Acesso ativado. Cada raça recebe seus desbloqueios ao ser selecionada.','Erişim etkin. Her ırk seçildiğinde kilitleri açılır.'):result==='error'?L203('No se pudo guardar el acceso. Libera espacio e inténtalo de nuevo.','Access could not be saved. Free some space and try again.','Não foi possível salvar o acesso. Libere espaço e tente de novo.','Erişim kaydedilemedi. Yer açıp yeniden dene.'):result==='identity'?L203('Restaura primero la partida correspondiente a este código.','First restore the save belonging to this code.','Restaure primeiro a partida deste código.','Önce bu koda ait kaydı geri yükle.'):result==='menu'?L203('Activa el acceso desde el menú principal y fuera de una sala.','Activate access from the main menu while outside a room.','Ative o acesso no menu principal e fora de uma sala.','Erişimi ana menüde ve oda dışında etkinleştir.'):L203('Este código no está autorizado. Tu partida no cambió.','This code is not authorized. Your save is unchanged.','Este código não está autorizado. Sua partida não mudou.','Bu kod yetkili değil. Kaydın değişmedi.');}],[L203('CERRAR','CLOSE','FECHAR','KAPAT'),closeDialog]]);}
if(STORE==='omni-forest-v1'){const b=document.createElement('button');b.id='tester-access203';b.setAttribute('data-no-i18n','');const label=()=>b.textContent=L203('ACCESO DE PRUEBA','TEST ACCESS','ACESSO DE TESTE','TEST ERİŞİMİ');label();const size=()=>b.style.setProperty('min-height',Math.max(44,44/Math.max(.25,Math.min(innerWidth/W,innerHeight/H)))+'px','important');size();addEventListener('resize',size,{passive:true});b.onclick=testerMenu203;recoveryPanel55.querySelector('div').appendChild(b);const setBefore203=OmniI18n.set;OmniI18n.set=function(...args){const out=setBefore203.apply(this,args);label();return out;};}
if(location.search.includes('qa=1'))window.__v203={eval:s=>eval(s),activeMissions203,activateTester203,testerAllowed203,missionJournal203,fastIcon203};
