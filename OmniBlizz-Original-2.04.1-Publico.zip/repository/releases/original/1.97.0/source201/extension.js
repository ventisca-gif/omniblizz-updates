// Original1.97: independent frame controls and measured world frames.
const perf201={frames:0,fps:0,p95:0,saveWrites:0,collisionTests:0};
// Actor visibility is already checked by drawActor200; Canvas clips the remaining pixels.
// Avoid a native getTransform() round trip and rectangle reconstruction on every image.
ctx.drawImage=nativeImage194;
const collisionGrids201=new WeakMap();
function solidRects201(rects,x,y,r){
 if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(r)||r<0)return rects.some(b=>x>b.x-r&&x<b.x+b.w+r&&y>b.y-r&&y<b.y+b.h+r);
 let grid=collisionGrids201.get(rects);
 if(!grid||grid.length!==rects.length){grid={length:rects.length,cells:new Map()};for(const b of rects)for(let cy=Math.floor(b.y/256);cy<=Math.floor((b.y+b.h)/256);cy++)for(let cx=Math.floor(b.x/256);cx<=Math.floor((b.x+b.w)/256);cx++){const key=cx+','+cy;let cell=grid.cells.get(key);if(!cell)grid.cells.set(key,cell=[]);cell.push(b);}collisionGrids201.set(rects,grid);}
 for(let cy=Math.floor((y-r)/256);cy<=Math.floor((y+r)/256);cy++)for(let cx=Math.floor((x-r)/256);cx<=Math.floor((x+r)/256);cx++)for(const b of grid.cells.get(cx+','+cy)||[]){perf201.collisionTests++;if(x>b.x-r&&x<b.x+b.w+r&&y>b.y-r&&y<b.y+b.h+r)return true;}return false;
}
// Metadata is serialized with the base snapshot, rather than rewriting it three times.
window.OmniSaveMetadata201=()=>({playerName93,edition93:CREATOR116?'creator':'official',houseIdentity97:identityHouse97(),housePlayerName97:localStorage.getItem('omni-house-name100')||'',recalCinema117:cinemaStyle117});
let simulationDepth201=0,saveQueued201=false;
const persistBefore201=persistGame,simulateBefore201=simulate75;
persistGame=function(...args){if(simulationDepth201){saveQueued201=true;return;}perf201.saveWrites++;return persistBefore201(...args);};
simulate75=function(...args){simulationDepth201++;try{return simulateBefore201(...args);}finally{if(--simulationDepth201===0&&saveQueued201){saveQueued201=false;persistGame();}}};
const npcZones201=REGIONS.map((_,z)=>Object.entries(NPCS25).filter(([id,n])=>['citizen','citizen2','officer'].includes(id)||id.startsWith('bellwood')?['citizen','citizen2','officer'].includes(id)||z===CITY21:n[2]===z&&n[3]>0));
function npcEntries201(z){return npcZones201[z]||[];}
// Manual 30/60 is authoritative. Low graphics changes effects, not the frame target.
targetFPS194=function(){return frameControl75.mode==='30'||frameControl75.mode==='auto'&&frameControl75.fps===30?30:60;};
const fpsMeter201=document.createElement('output');fpsMeter201.id='fps201';fpsMeter201.setAttribute('data-no-i18n','');fpsMeter201.style.cssText='position:fixed;bottom:4px;left:50%;transform:translateX(-50%);z-index:10000;color:#d9ffb3;background:#071b17d9;padding:2px 7px;font:11px monospace;pointer-events:none';document.body.appendChild(fpsMeter201);
let meterEnabled201=localStorage.getItem('omni-fps-meter201')!=='off',frameTimes201=[],meterLast201=0;
function updateMeter201(){fpsMeter201.hidden=!meterEnabled201;fpsMeter201.textContent=perf201.fps+' FPS / '+targetFPS194()+' · '+perf201.p95+' ms';}
function sampleFrame201(now,render){
 if(document.hidden){frameTimes201=[];return;}
 if(render&&started&&!paused&&!cinematic){perf201.frames++;frameTimes201.push(now);}else if(!started||paused||cinematic)frameTimes201=[];
 while(frameTimes201.length&&frameTimes201[0]<now-2000)frameTimes201.shift();
 if(now-meterLast201<500)return;meterLast201=now;
 const times=frameTimes201.filter(t=>t>=now-1000),gaps=[];for(let i=1;i<times.length;i++)gaps.push(times[i]-times[i-1]);
 perf201.fps=times.length>1?Math.round((times.length-1)*1000/(times[times.length-1]-times[0])):0;gaps.sort((a,b)=>a-b);perf201.p95=Math.round(gaps[Math.max(0,Math.ceil(gaps.length*.95)-1)]||0);updateMeter201();
}
function meterButton201(){const b=document.createElement('button');b.setAttribute('data-no-i18n','');b.textContent=L148('CONTADOR FPS','FPS COUNTER','CONTADOR FPS','FPS SAYACI')+' · '+(meterEnabled201?'ON':'OFF');b.onclick=()=>{meterEnabled201=!meterEnabled201;localStorage.setItem('omni-fps-meter201',meterEnabled201?'on':'off');updateMeter201();b.textContent=L148('CONTADOR FPS','FPS COUNTER','CONTADOR FPS','FPS SAYACI')+' · '+(meterEnabled201?'ON':'OFF');};return b;}
const settingsBefore201=settings15;settings15=function(...args){const out=settingsBefore201(...args);$('#dialogbuttons').prepend(meterButton201());return out;};
const raceBefore201=raceMenu;raceMenu=function(...args){const out=raceBefore201(...args);$('#dialogbuttons').append(meterButton201());return out;};
$('#musicbtn').onclick=()=>settings15();$('#racebtn').onclick=()=>raceMenu();
document.addEventListener('visibilitychange',()=>{frameTimes201=[];meterLast201=0;perf201.fps=0;perf201.p95=0;frameControl75.lastDraw=-Infinity;updateMeter201();});
updateMeter201();
if(location.search.includes('qa=1'))window.__v201={eval:s=>eval(s),perf:perf201,sampleFrame201,solidRects201};
