OmniBlizz Original 1.97

Original 1.97: repairs updater pack size compatibility (all packs <=8 MiB), separates graphics quality from manual 30/60 FPS, adds actual world FPS and frame-time counter, reduces repeated save serialization, indexes base collision queries and limits NPC discovery scans. Includes all previous content and fixes. Desktop automated coverage is not a physical Android FPS guarantee.

El selector 30/60/automático controla los FPS; gráficos ligeros controla los efectos. El contador muestra FPS dibujados y p95 del intervalo de cuadros. No se ha probado en el teléfono del usuario.
