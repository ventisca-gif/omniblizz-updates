OmniBlizz Original 1.98

Original 1.98: rasterized HUD frames for Omnitrix and Anodite; isolated HUD compositing; simulation synchronized with render deadlines so 30 FPS avoids redundant full updates. Elapsed gameplay time and bounded physics steps are retained. Reduces enemy casting scan allocations. Preserves other races, all powers and previous fixes. Physical Android FPS is not guaranteed.

El selector 30/60/automático controla los FPS; gráficos ligeros controla los efectos. El contador muestra FPS dibujados y p95 del intervalo de cuadros. No se ha probado en el teléfono del usuario.
