// Original1.98: cached HUD textures and render-aligned simulation.
// Replace the existing HUD stylesheet; don't retain a duplicate selector tree.
const style202=hudStyle190;style202.href='content202/hud.css';
const renderStats202={callbacks:0,simulations:0,draws:0,seconds:0,updateMs:0,drawMs:0};
let pendingTime202=0;
const loopBefore202=loop;
// At 30 FPS, two 60 Hz callbacks now share one simulation transaction.
// The elapsed time is accumulated, rather than discarded or passed as a larger unsafe physics step.
loop=function(now){
 // Keep the existing loop for races the device already runs smoothly.
 if(race!=='omni'&&race!=='anodite'){pendingTime202=0;return loopBefore202(now);}
 requestAnimationFrame(loop);const elapsed=Math.max(0,(now-last)/1000||0);last=now;countPlay56(elapsed);renderStats202.callbacks++;
 if(!ready){pendingTime202=0;return;}
 pendingTime202+=elapsed;const render=frameControl75.render(now,quality17);
 if(!render){sampleFrame201(now,false);frameControl75.sample(elapsed*1000,0,started&&!paused&&!cinematic&&!document.hidden&&window.omniMode61!==null);return;}
 const passed=pendingTime202,begin=performance.now();pendingTime202=0;
 window.OmniSound?.ambient(started&&!paused&&!net.remoteAway&&!net.waiting&&!document.hidden,sound,zone,dayMode);
 netUpdate(Math.min(.1,passed));updateCinema(passed);
 const tick=performance.now();
 if(started&&!paused&&!net.remoteAway&&!net.waiting){simulate75(passed);renderStats202.simulations++;renderStats202.seconds+=Math.min(.25,passed);}else if(!started)clock+=Math.min(.04,passed);
 renderStats202.updateMs+=performance.now()-tick;const paint=performance.now();draw();drawCinema();renderStats202.drawMs+=performance.now()-paint;renderStats202.draws++;
 sampleFrame201(now,true);frameControl75.sample(elapsed*1000,performance.now()-begin,started&&!paused&&!cinematic&&!document.hidden&&window.omniMode61!==null);
};
document.addEventListener('visibilitychange',()=>{pendingTime202=0;last=performance.now();frameControl75.lastDraw=-Infinity;});
// Avoid allocating keys arrays and a new regular expression for every enemy on every step.
const castKey202=/^(?:cast|wind)/;
casting89=function(e){for(const k in e)if(Object.prototype.hasOwnProperty.call(e,k)&&castKey202.test(k)&&(typeof e[k]==='object'?!!e[k]:Number(e[k])>0))return true;return false;};
if(location.search.includes('qa=1'))window.__v202={eval:s=>eval(s),stats:renderStats202};
