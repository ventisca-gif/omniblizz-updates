OmniBlizz Original1.90

Original1.93: Fasttrack hologram above recalibrated watch, correct directional walking and padded race sprites. Supplied transformation video with audio and double-tap skip; Helen unlock guidance. Shadow XP from all hostile enemy death paths, level40 cap. Max AF Highbreed reputation patrols on current Anur and Petropia and rare Earth encounters, only with active mission. Reputation tiers70000/80000/90000HP and400/500/600attack. New UI in ES EN PT TR. Includes all1.92 content.

136maps,48alien definitions,12Osmosian forms and10video files preserved. No physical Android FPS claim.
