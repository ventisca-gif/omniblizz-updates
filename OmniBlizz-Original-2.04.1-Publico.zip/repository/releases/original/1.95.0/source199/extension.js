// Original1.95: Highbreed identity and saved patrol migration.
function repairHighbreed199(){const lists=new Set([enemies,...Object.values(zoneStates)]);for(const list of lists)if(Array.isArray(list))for(const e of list)if(e?.highbreed197){delete e.petro137;e.mob78='highbreed197';}}
const initBefore199=initProgress;initProgress=function(...a){const r=initBefore199(...a);repairHighbreed199();return r;};
repairHighbreed199();
if(location.search.includes('qa=1'))window.__v199={eval:s=>eval(s)};
