OmniBlizz Original 2.04.0

Original 2.04.0: independent combat mastery 0-300 for every Recalibrated alien, Osmosian absorption, Anodite form and Bendy form. Each point adds 1% damage and 0.2% HP. Slow active-use XP through level 50, real combat participation, tougher progression, elite and boss rewards, per-form saves and four languages. Prototype, System, Saiyan, Pokemon and Rojo are excluded; skill mastery is preserved.

Cambio rápido exclusivo del Recalibrado desde nivel 150. Dos diales, coste 10, cambio directo y tiempo ralentizado al elegir. Español, English, Português, Türkçe.
