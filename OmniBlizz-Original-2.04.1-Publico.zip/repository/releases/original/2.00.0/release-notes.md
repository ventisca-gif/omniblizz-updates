OmniBlizz Original 2.00.0

Original 2.00.0: adds Undertale Rojo as an eighth independent multiversal race. Reference selection card, four-direction walking, orange story panels, seamless connected opening ruins, Flowey tutorial, red-soul bullet dodging, timed FIGHT, ACT, items, MERCY, independent LV1/20HP progression and checkpoints. ES/EN/PT/TR adaptation with original dialogue. Compatible cloud profile envelope and server validation; preserves prior races and performance work.

Rojo llega a las razas multiversales. Introducción, caminos conectados y primer encuentro con Flowey; progreso y respaldo independientes.
