OmniBlizz Original 1.99.1

Original 1.99.1: repairs mission journal touch scrolling and arrow navigation. Authorized test access can be redeemed once and is permanently bound to the first installation through an atomic server claim. Retries on that installation are safe; other installations are denied. Preserves existing content and rendering improvements.

Desplazamiento de misiones reparado. Código de prueba de un solo uso, vinculado a la primera instalación. El código privado no se publica.
