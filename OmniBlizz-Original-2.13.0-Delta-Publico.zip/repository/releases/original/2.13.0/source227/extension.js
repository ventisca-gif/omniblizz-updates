// Original 2.13.0: live update notices and an actual Hatchery phone chassis.
const release227='2.13.0',L227=(...s)=>words97(...s),phoneSkin227=()=>lootEligible226()&&!!raidState225().skinOwned&&!!raidState225().skinEquipped;
const newer227=(v,base)=>{if(base===undefined){base=release227;const current=window.OmniUpdates147?.version;if(newer227(current,base))base=current;}const a=String(v).split('.').map(Number),b=String(base).split('.').map(Number);if(a.length!==3||a.some(x=>!Number.isSafeInteger(x)||x<0))return false;for(let i=0;i<3;i++){if(a[i]!==b[i])return a[i]>b[i];}return false;};
const noticeKey227='omni-update-notice227-'+(window.OMNI_UPDATE_CONFIG147?.edition||'original');let notice227='',pending227=false,lastCheck227=0,checking227=false;
try{const v=localStorage.getItem(noticeKey227);if(newer227(v))notice227=v;}catch{}
function updateLabel227(){return notice227?L227('ACTUALIZACIÓN DISPONIBLE','UPDATE AVAILABLE','ATUALIZAÇÃO DISPONÍVEL','GÜNCELLEME MEVCUT'):L227('ACTUALIZACIONES','UPDATES','ATUALIZAÇÕES','GÜNCELLEMELER');}
function rememberNotice227(v){if(v&&!newer227(v))v='';if(notice227!==v){notice227=v;try{if(v)localStorage.setItem(noticeKey227,v);else localStorage.removeItem(noticeKey227);}catch{}}paintNotice227();}
function paintNotice227(){const button=$('#main-updates223'),span=button?.querySelector('span');if(span)text193(span,updateLabel227());for(const b of [button,phoneButton105,...phone105.querySelectorAll('[data-phone105="updates147"]')]){if(!b)continue;b.classList.toggle('update-ready227',!!notice227);if(b===button)b.setAttribute('aria-label',updateLabel227()+(notice227?' · '+notice227:''));if(b.dataset.phone105==='updates147'){const s=b.querySelector('span');if(s)text193(s,updateLabel227());}if(notice227)b.setAttribute('data-update227',notice227);else b.removeAttribute('data-update227');}}
// Read only the signed updater's rendered result. The updater retains verification,
// download, installation and rollback; this bridge never trusts unsigned metadata.
function readNotice227(){const panel=$('#updates-panel147');if(!panel)return;const text=panel.textContent||'',match=text.match(/(?:Nueva versión |New version available: |Nova versão disponível: |Yeni sürüm var: )(\d+\.\d+\.\d+)/);if(match){pending227=false;rememberNotice227(newer227(match[1])?match[1]:'');}else if(/Ya tienes la última versión|You have the latest version|Você tem a versão mais recente|En güncel sürümü/.test(text)){pending227=false;rememberNotice227('');}else if(/Actualización verificada y lista|Update verified and ready|Atualização verificada e pronta|Güncelleme doğrulandı/.test(text)){pending227=!!notice227;paintNotice227();}}
async function checkNotice227(){const u=window.OmniUpdates147;if(!u?.check||checking227||pending227||document.hidden||navigator.onLine===false||Date.now()-lastCheck227<60000)return;checking227=true;lastCheck227=Date.now();try{await u.check();readNotice227();}catch{}finally{checking227=false;}}
let observedPanel227=null;const noticeObserver227=new MutationObserver(()=>readNotice227());function attachNotice227(){const p=$('#updates-panel147');if(p&&p!==observedPanel227){noticeObserver227.disconnect();noticeObserver227.observe(p,{childList:true,subtree:true,characterData:true});observedPanel227=p;readNotice227();}}
window.addEventListener('online',checkNotice227);window.addEventListener('focus',checkNotice227);document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkNotice227();});setTimeout(()=>{attachNotice227();checkNotice227();},1800);setInterval(()=>{attachNotice227();checkNotice227();},600000);
const appsBefore227=phoneApps105;phoneApps105=function(){return appsBefore227().map(a=>a[0]==='updates147'?[a[0],notice227?['Actualización disponible','Update available','Atualização disponível','Güncelleme mevcut']:a[1],a[2]]:a);};
let skinLast227=null;function syncSkin227(){const equipped=phoneSkin227();if(equipped!==skinLast227){skinLast227=equipped;phoneButton105.classList.toggle('hatchery-button227',equipped);const im=phoneButton105.querySelector('img');if(im){im.src=url223(equipped?'phone227/closed.webp':'assets/phone105/closed.webp');im.alt='';}}if(!phone105.hidden){phone105.classList.toggle('hatchery227',equipped);const im=phone105.querySelector('.phone-frame105');if(im){const path=url223(equipped?'phone227/open.webp':'assets/phone105/open.webp');if(im.getAttribute('src')!==path)im.src=path;}}}
const openBefore227=openPhone105;openPhone105=function(...a){const r=openBefore227(...a);syncSkin227();paintNotice227();attachNotice227();return r;};phoneButton105.onclick=()=>openPhone105();
const hudBefore227=hud;hud=function(...a){const r=hudBefore227(...a);syncSkin227();return r;};
const paintBefore227=paintMenuAvatar71;paintMenuAvatar71=function(...a){const r=paintBefore227(...a);paintNotice227();attachNotice227();return r;};
const bagEntriesBefore227=bagEntries217;bagEntries217=function(){const a=bagEntriesBefore227(),item=a.find(e=>e.id==='raidcosmetic:skin');if(item){item.description=L227('Skin del teléfono Hatchery: marco xenocita morado con luces verdes. Cambia el teléfono abierto y su icono exterior; se guarda por raza.','Hatchery phone skin: purple Xenocite frame with green lights. Changes the open phone and its HUD icon; saved separately per race.','Skin de telefone Hatchery: moldura xenocita roxa com luzes verdes. Altera o telefone aberto e o ícone; salva por raça.','Hatchery telefon görünümü: yeşil ışıklı mor Xenocite çerçeve. Açık telefonu ve simgesini değiştirir; ırk başına kaydedilir.');const action=item.action;item.action=()=>{action();syncSkin227();};}return a;};
const itemArtBefore227=itemArt226;itemArt226=function(id){return id==='skin'?'<span class="item-art226 hatchery-art227" aria-hidden="true" style="background-image:url('+url223('phone227/closed.webp')+');background-size:contain;background-position:center"></span>':itemArtBefore227(id);};raidArt225=itemArt226;
const skinStyle227=document.createElement('style');skinStyle227.textContent=`
#phone105.hatchery227 .phone-device105{width:min(98vw,174vh,1320px)!important;aspect-ratio:1672/941!important;isolation:isolate;background:none!important}
#phone105.hatchery227 .phone-device105:before{content:'';position:absolute;inset:12% 13% 17%;background:#020e0c;z-index:-1;pointer-events:none}
#phone105.hatchery227 .phone-frame105{filter:none!important;z-index:3;object-fit:fill;pointer-events:none}
#phone105.hatchery227 .phone-left105{left:14%;top:15%;width:30%;height:64%;background:none!important;color:#a9f64c;z-index:2}
#phone105.hatchery227 .phone-right105{left:56%;top:15%;width:29%;height:64%;z-index:2;--phone-color:#a9f64c}
#phone105.hatchery227 .phone-apps105 button{border-color:#50748a!important;box-shadow:inset 2px 2px #638e9f,inset -2px -3px #061017!important;border-radius:.5cqw!important}
#phone105.hatchery227 .phone-emblem105{height:8cqw;width:8cqw;margin:.5cqw 0}
#phone105.hatchery227 .phone-left105 canvas{height:47%;max-width:95%;filter:none!important}
#phone105.hatchery227 .phone-status105{font-size:1.35cqw;margin-bottom:.4cqw}
#phone105.hatchery227 .phone-left105 small{font-size:1.25cqw}
#phone105.hatchery227 .phone-right105 header{height:8%;font-size:1.7cqw}
#phone105.hatchery227 .phone-apps105 svg{width:4.3cqw!important;height:4.3cqw!important;min-height:0!important;flex:0 1 4.3cqw!important}
#phone105.hatchery227 .phone-apps105.raid-page225 svg{width:3.5cqw!important;height:3.5cqw!important;flex-basis:3.5cqw!important}
#phone105.hatchery227 .phone-apps105 button{font-size:1.18cqw!important;gap:.2cqw!important;padding:.3cqw!important}
#phone105.hatchery227 .phone-pages114{height:10%;grid-template-columns:5cqw 1fr 5cqw;font-size:1.2cqw!important}
#game #hud.hud86[data-skin162] #phone-button105.hatchery-button227 img,#phone-button105.hatchery-button227 img{filter:none!important;height:94%!important;width:100%;object-fit:contain}
#game #hud.hud86[data-skin162] #phone-button105.hatchery-button227 small,#phone-button105.hatchery-button227 small{color:#a9f64c;background:#081512dc;position:absolute;bottom:0;left:-10%;right:-10%;font-size:8px;border:1px solid #4b2b65;padding:2px}
#menu #main-updates223.update-ready227{width:230px!important;border-color:#dcff8d!important;background:#315f16!important;color:#eaffbd!important;box-shadow:inset 2px 2px #74a34d!important}
#main-updates223.update-ready227:after,#phone-button105.update-ready227:after,[data-phone105="updates147"].update-ready227:after{content:'!';position:absolute;top:-5px;right:-5px;width:18px;height:18px;line-height:18px;border:2px solid #ffe7a0;background:#ce3f37;color:#fff;font:bold 13px/18px monospace;border-radius:50%;pointer-events:none}
[data-phone105="updates147"].update-ready227{position:relative;overflow:visible!important;border-color:#c4ff78!important}
body:has(#main-updates223.update-ready227) #menu .menu-bottom{right:260px!important}
`;document.head.append(skinStyle227);
if(location.search.includes('qa=1'))window.__phone227={eval:s=>eval(s)};
