OmniBlizz Original 2.13.0

Original 2.13.0: real purple Xenocite Hatchery phone frame and HUD icon when equipped, for Omnitrix, Osmosian, Anodite, Bendy and System. Update available notice in the main menu and phone, driven by verified updater results, automatic periodic and reconnect checks, preserved through temporary offline periods. ES/EN/PT/TR.
