// Recheck after the candidate is committed; a check during image loading may have
// compared against the previous active revision and left a stale download offer.
if(window.OmniUpdates147?.contentReady189){
 const readyBefore300=window.OmniUpdates147.contentReady189;
 let readyPromise300=null;
 window.OmniUpdates147.contentReady189=function(...args){
  return readyPromise300||=(async()=>{await readyBefore300.apply(this,args);await this.check?.();})();
 };
}
document.documentElement.classList.add('entry-ready300');
