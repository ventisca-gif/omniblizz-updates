# OmniBlizz · siguiente revisión en preparación

Base pública: 2.36.7, revisión 299. No se ha publicado la siguiente revisión.

- Se reproduce una oferta obsoleta del actualizador: check() termina antes de activar el candidato; available sigue apuntando a la versión ya activada. El puente candidato vuelve a comprobar después de contentReady189(). No se ha confirmado que explique todos los casos Android.
- La entrada oculta el diseño previo hasta terminar la decoración actual y muestra un estado de carga.
- Prueba Prototipo: iframe con estado y almacenamiento temporales propios, sin acceso a partidas, IndexedDB ni conexiones de nube/multijugador. Nivel 140, vitalidad Ten 25, entrenamiento completo, habilidades aprendidas; lista limitada al Prototipo. Enemigos invocables con límite 12. Al salir se elimina la sesión del iframe. Todavía no está validada la ejecución del motor completo ni su disposición visual.
- Tests nuevos: 7 arranque/actualizador, 45 aislamiento, 29 configuración del Prototipo. Son unidades extraídas o entornos simulados, no validación Android.

Pendiente antes de publicar: ejecutar en navegador el motor completo, revisar transformaciones de todos los prototipos, controles, fallos/cierre, progreso normal intacto, actualización/reinicio y perfiles de CPU/GPU. Codespaces mantiene Modo restringido y exige «Confiar en la carpeta y continuar» antes de permitir un terminal; no se ha aceptado ese cambio.

La captura del usuario muestra 41 FPS con objetivo 60. Esto no permite prometer 60 ni concluir un límite irreversible del teléfono. No se han agotado las mediciones.
