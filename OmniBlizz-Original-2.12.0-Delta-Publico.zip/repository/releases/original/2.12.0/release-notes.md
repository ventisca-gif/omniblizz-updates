OmniBlizz Original 2.12.0

Original 2.12.0: useful raid loot for Omnitrix, Osmosian, Anodite, Bendy and System. Generated pixel inventory atlas. Research and crafting, timed tonics, racial energy restoration, one small modifier per form, exploration visor, world containment emitter, insulated boots, fragment exchange and placeable house trophy. Bendy raid access. ES/EN/PT/TR.
