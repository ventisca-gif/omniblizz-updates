# OmniBlizz Original 2.41.1 · Misiones importantes y avisos

- Aviso de entrada y recuadro de ruta: desaparecen tras 10 segundos reales. La flecha elegida permanece activa y no cambia la partida.
- Botones de misiones con fondo verde oscuro y texto claro; controles bloqueados legibles.
- Catálogo de misiones de nivel/EXP, con Max, Ten, Ten AF, informante DNAlien, Monkey, Phill, Kai, Orden, mineros y Vulkanus. Añade Max AF de la Rustbucket y Plomero Max AF con sus guías y requisitos propios.
- Guías, flechas y viaje opcional al NPC, con requisitos de nivel y restricciones de combate conservados.
- Nuevos paneles, controles y detalles de Minas/Vulkanus traducidos a español, inglés, portugués y turco. Ruta de Monkey explica el límite actual de 200.
- Vulkanus conserva 850.000 de vida y 3.500 de daño base.

36 comprobaciones en navegador: cuatro idiomas, contraste, catálogo sin duplicados, controles, niveles, temporizadores reales y estadísticas de Vulkanus. Sin prueba física Android. Esta publicación actualiza Original; no contiene un manifiesto Creator verificado.
