OmniBlizz Original 2.14.0

Original 2.14.0: pixel field archive Omnipedia with existing aliens, absorptions, enemies, NPCs, races, missions and locations; search, grid/list, touch scrolling and full legacy files. Real saved-profile HP, effective damage multiplier including combat mastery, and actual skill data. No invented aliens or weakness panel. Host-controlled raid intermission skip synchronized through normal world snapshots. ES/EN/PT/TR.
