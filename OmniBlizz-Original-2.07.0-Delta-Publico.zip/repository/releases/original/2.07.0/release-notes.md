OmniBlizz Original 2.07.0

Original 2.07.0: Rojo online battles now share one enemy and a turn queue. Each participant keeps their own LV, HP, items and controllable heart; the common enemy attack deals individual damage. Party-scaled enemy HP, surviving teammates, shared victory or mercy, once-only rewards, Flowey and Toriel rescue, disconnect handling and coordinator migration. Existing solo play and other races preserved.
