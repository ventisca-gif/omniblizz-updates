OmniBlizz Original 2.08.0

Original 2.08.0: redesigned phones for Omnitrix, Anodite, Osmosian and System with uniform nine-slot pages, icons and racial colors. Refreshed main menu preserves every action and displays the selected race portrait for all eight races. Mission command journal with categories, NPC portraits, location thumbnails, actual objective counters and working tracking/map/phone actions. ES/EN/PT/TR. Static reused artwork and cached portraits; combat, progression and online unchanged.
