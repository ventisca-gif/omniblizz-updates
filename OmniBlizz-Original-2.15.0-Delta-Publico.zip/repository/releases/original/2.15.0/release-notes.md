OmniBlizz Original 2.15.0

Original 2.15.0: fix live Omnipedia portraits and preserve locked silhouettes. New Drops and Crafting phone apps beside Raids for Omnitrix, Osmosian, Anodite, Bendy and System. Searchable real drop-source guide, all basic and raid materials, smoothies, season components, devices and cosmetics; existing recipes and exact inventory costs, research, upgrades and exchanges. ES/EN/PT/TR. New generated pixel art app icons. Crafting capacity guard.
