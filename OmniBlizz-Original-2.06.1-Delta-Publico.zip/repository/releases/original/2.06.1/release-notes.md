OmniBlizz Original 2.06.1

Original 2.06.1: includes the 2.06.0 illustrated inventory, timed XP and mastery smoothies, crafting, ranks, mission journal and same-race online modes; fixes inventory and badge icons loading from downloaded Original content. Saved progression preserved.
