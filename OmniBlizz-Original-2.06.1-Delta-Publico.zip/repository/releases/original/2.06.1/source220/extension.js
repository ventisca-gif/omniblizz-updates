// Original 2.06.1: resolve inventory atlas URLs from downloaded content before dynamic insertion.
const atlasBefore220=atlasIcon219;atlasIcon219=function(...a){return atlasBefore220(...a).replace(/url\((art219\/[^)]+)\)/g,(_,p)=>'url('+(window.OmniUpdates147?.resolve?.(p)||p)+')');};
