# OmniBlizz Original 2.41.0 · Minas y Vulkanus

- Minas de taedenita conectadas al Desierto Dorado. Misión nivel 200: cuatro mineros, 400.000 de vida cada uno, 2.000 de daño y ataques de pico incluso a corta distancia.
- Dos entregas completas por nivel del 200 al 210. Después, repetible sin experiencia.
- Cámara de Vulkanus a la izquierda de las Minas. Jefe de 850.000 de vida, con caminata, ataques y efectos. Dos victorias entregadas por nivel del 210 al 225; después sin experiencia.
- Teléfono: «Misiones importantes», con flecha activable/desactivable y viaje opcional al NPC fuera de combate.
- Aviso al entrar según tu nivel, con cierre y viaje opcional. Se muestra una sola vez por sesión.
- Progreso guardado por raza; conserva el contenido de 2.40.1 y las firmas originales.

Validación en navegador: recompensas, límites, golpes simultáneos, persistencia serializada, flechas, requisitos de nivel y cierre del aviso. Sin prueba en Android físico.
