let firstBoot189=false;
function size189(n){return (n/1000000).toFixed(1)+' MB';}
function L189(es,en,pt,tr){const lang=localStorage.getItem('omni-language')||navigator.language?.slice(0,2)||'es';return ({es,en,pt,tr})[lang]||es;}
function initial189(){firstBoot189=true;document.body.innerHTML='<main id="download189"><div class="brand189">OMNIBLIZZ · '+(C.edition==='creator'?'CREATOR':'ORIGINAL')+'</div><h1></h1><p class="intro189"></p><div id="gate-body189"></div><div id="gate-actions189"></div><p class="foot189"></p></main>';document.querySelector('#download189 h1').textContent=L189('Prepara tu aventura','Prepare your adventure','Prepare sua aventura','Macerana hazırlan');document.querySelector('.intro189').textContent=L189('Descarga el contenido una vez. Después podrás jugar sin conexión y entrar a los mapas sin descargar por separado.','Download the content once. Then play offline and enter maps without separate downloads.','Baixe o conteúdo uma vez. Depois jogue offline e entre nos mapas sem downloads separados.','İçeriği bir kez indir. Sonra çevrimdışı oyna ve haritalara ayrı indirme olmadan gir.');document.querySelector('.foot189').textContent=L189('Tus partidas se conservan. Si se interrumpe, se reutilizan los archivos ya verificados.','Your saves are kept. After an interruption, verified files are reused.','Seus saves são mantidos. Após uma interrupção, os arquivos verificados são reutilizados.','Kayıtların korunur. Kesinti sonrası doğrulanmış dosyalar yeniden kullanılır.');body=document.querySelector('#gate-body189');actions=document.querySelector('#gate-actions189');render();}
async function launch189(){
 await mount();if(config.candidate&&selected===config.candidate){config.trial=true;await saveConfig();}
 firstBoot189=false;body=actions=null;installResolvers();let html=window.OMNI_BASE_ENTRY147;
 html=await(await nativeFetch(urls.get('game-entry147.html'))).text();if(C.edition==='creator')html=html.replaceAll('OMNIBLIZZ ORIGINAL','OMNIBLIZZ CREATOR').replace('<title>OmniBlizz</title>','<title>OmniBlizz Creator</title>');
 document.open();document.write(rewriteHTML(html));document.close();
 setTimeout(()=>{if(config.candidate&&!bootDone)rollbackTrial();},90000);setTimeout(()=>{attach();if(db)check();},1000);
}
async function boot(){
 try{await openDB();if(config.trial&&config.candidate){config.candidate=null;config.trial=false;await saveConfig();status=L189('El último arranque no terminó. Se conserva tu partida.','The last startup did not finish. Your save is kept.','A última inicialização não terminou. Seu save foi mantido.','Son açılış tamamlanmadı. Kaydın korundu.');}
  selected=[config.candidate,config.active].find(x=>x?.manifest?.schema===2&&x.manifest.full===true)||null;
  if(selected){try{await launch189();return;}catch{for(const u of urls.values())URL.revokeObjectURL(u);urls.clear();selected=null;}}
 }catch{db=null;status=L189('No se pudo abrir el almacenamiento. Reinicia la aplicación.','Storage could not be opened. Restart the app.','Não foi possível abrir o armazenamento. Reinicie o app.','Depolama açılamadı. Uygulamayı yeniden başlat.');}
 initial189();if(db)await check();
}
// Old gameReady hooks run before image loading; acknowledge only after actual game boot.
async function gameReady(){return;}
async function contentReady189(){if(bootDone)return;bootDone=true;if(db&&config.candidate){config.previous=config.active?.manifest?.schema===2?config.active:null;config.active=config.candidate;config.candidate=null;config.trial=false;await saveConfig();await cleanup();}attach();}
