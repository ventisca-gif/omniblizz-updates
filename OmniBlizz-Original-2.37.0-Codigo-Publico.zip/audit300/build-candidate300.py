from pathlib import Path
import json,base64
root=Path(__file__).resolve().parent.parent
p=root/'audit300/candidate'
s=(root/'diagnostics299/candidate-game.js').read_text()
old="mapPaint($('#minimap').getContext('2d'),zone,110,62);"
assert s.count(old)==1
s=s.replace(old,"const miniCanvas300=$('#minimap');if(miniCanvas300.getClientRects().length)mapPaint(miniCanvas300.getContext('2d'),zone,110,62);")
marker='const drawFrameBefore299=draw;'
assert s.count(marker)==1
s=s.replace(marker,(p/'boot-fixes300.js').read_text()+'\n'+marker)
a=s.rfind('})();');assert a>0
s=s[:a]+(p/'trial-isolation300.js').read_text()+'\n'+(p/'prototype-trial300.js').read_text()+'\n'+s[a:]
(p/'game.js').write_text(s)
m=json.loads(base64.b64decode(json.loads((root/'release299/original-manifest.json').read_text())['payload']))
f=next(f for f in m['files'] if f['path']=='game-entry147.html')
html=(root/('release299/original-'+f['sha256']+'.bin')).read_text().replace('2.36.7','2.36.8').replace('game.js?v=299','game.js?v=300')
head='<style id="entry-load300">html:not(.entry-ready300) #entry61{visibility:hidden}#entry-loading300{position:fixed;inset:0;z-index:9999;display:grid;place-items:center;background:#061811;color:#d9ffa1;font:18px monospace}html.entry-ready300 #entry-loading300{display:none}html.trial-loading300 #entry-loading300{display:grid!important}html.trial-loading300 #entry61{visibility:hidden!important}</style>'
html=html.replace('</head>',head+'</head>').replace('<body data-entry61="pending">','<body data-entry61="pending"><div id="entry-loading300" role="status">OmniBlizz · Cargando interfaz…</div>')
(p/'game-entry147.html').write_text(html)
