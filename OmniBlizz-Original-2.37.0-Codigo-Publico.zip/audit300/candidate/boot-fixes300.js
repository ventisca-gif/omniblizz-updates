// Recheck after the candidate is committed; a check during image loading may have
// compared against the previous active revision and left a stale download offer.
if(window.OmniUpdates147?.contentReady189){
 const readyBefore300=window.OmniUpdates147.contentReady189;
 let readyPromise300=null;
 window.OmniUpdates147.contentReady189=function(...args){
  return readyPromise300||=(async()=>{await readyBefore300.apply(this,args);await this.check?.();})();
 };
}
document.documentElement.classList.add('entry-ready300');

if($('#entry61 .entry-eyebrow61'))$('#entry61 .entry-eyebrow61').textContent='OMNIBLIZZ '+(CREATOR116?'CREATOR':'ORIGINAL')+' · 2.36.8';

readyLog23=function(){logFirst23=true;};
function versionUI300(){const label='OMNIBLIZZ '+(CREATOR116?'CREATOR':'ORIGINAL')+' · 2.36.8';if($('#entry61 .entry-eyebrow61'))$('#entry61 .entry-eyebrow61').textContent=label;if($('#menu .eyebrow'))$('#menu .eyebrow').textContent=label;document.title=label;}
versionUI300();
const versionAfter300=()=>{if(!ready)return requestAnimationFrame(versionAfter300);versionUI300();};versionAfter300();
