# OmniBlizz Original 2.36.8 · Prueba del Prototipo y arranque

- Nuevo botón «Prueba Omnitrix Prototipo · NV.140» en el menú principal. Sesión temporal con las 26 formas del Prototipo, habilidades desbloqueadas y mejoras de Ten. Permite invocar enemigos, limpiar y recuperar vida/energía. No incluye formas exclusivas del Recalibrado.
- La prueba usa un estado y almacenamiento propios en memoria. No lee ni escribe partidas normales, no conecta a nube/multijugador y se descarta al salir o cerrar la página. Volver a jugar normalmente conserva tu progreso real.
- La pantalla inicial muestra una carga breve hasta que está preparado su diseño actual, evitando mostrar primero el diseño anterior. Rótulos de versión actualizados.
- Al terminar de activar una actualización se comprueba de nuevo su estado para retirar una oferta obsoleta de descargar esa misma versión. Se conserva la verificación de firmas y recuperación del cargador.
- El minimapa antiguo deja de repintarse cuando está oculto; siguen disponibles los mapas visibles y el atlas. Se mantienen las mejoras de caché, reloj y listas de compañeros de la versión 2.36.7.

Validación: sintaxis, firmas y 516 comprobaciones automatizadas. En navegador de nube: 26 transformaciones y llamadas a ataques/renderizado sin excepciones; almacenamiento normal idéntico durante la prueba y después de salir; progreso normal conservado al recargar. Comprobado el desplazamiento de Mascotas y Monturas. También se probó la adaptación Creator de referencia: 26 formas y guardado normal intacto al salir; la APK instalada puede contener una adaptación posterior.

La prueba del navegador usa partidas de prueba; no reproduce la partida afectada ni el rendimiento de Android físico. Esta revisión no declara resuelta toda la regresión ni promete 60 FPS. La oferta repetida identificada es un caso reproducido; otros fallos del actualizador pueden requerir comprobación en el teléfono.
