async function verifiedManifest(envelope){
 if(!crypto.subtle)throw Error('Actualiza Android System WebView para verificar las actualizaciones.');
 if(!envelope||typeof envelope.payload!=='string'||typeof envelope.signature!=='string'||envelope.payload.length>3*1024*1024)throw Error('Manifiesto inválido');
 const raw=b64(envelope.payload),pem=C.publicKey.replace(/-----[^-]+-----|\s/g,''),key=await crypto.subtle.importKey('spki',b64(pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
 if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,b64(envelope.signature),raw))throw Error('La firma de la actualización no es válida.');
 const m=JSON.parse(dec.decode(raw));if(m.schema!==2||m.full!==true||m.edition!=='original'||!Number.isSafeInteger(m.revision)||m.revision<C.baseRevision||(!Number.isSafeInteger(m.minShell)||m.minShell<189)||typeof m.version!=='string'||m.version.length>40||!Array.isArray(m.files)||m.files.length>20000||!Array.isArray(m.packs)||m.packs.length>2000)throw Error('Actualización incompatible');
 const packs=new Map();for(const p of m.packs){if(!/^[a-f0-9]{64}$/.test(p.sha256)||packs.has(p.sha256)||!Number.isSafeInteger(p.bytes)||p.bytes<0||p.bytes>8*1024*1024||!validURL(p.url))throw Error('Paquete inválido');packs.set(p.sha256,p);}
 let total=0;const paths=new Set();for(const f of m.files){const p=packs.get(f.pack);if(!safePath(f.path)||paths.has(f.path)||!Number.isSafeInteger(f.bytes)||f.bytes<0||f.bytes>MAX||!/^[a-f0-9]{64}$/.test(f.sha256)||!p||!Number.isSafeInteger(f.offset)||f.offset<0||f.offset+f.bytes>p.bytes||typeof f.mime!=='string'||f.mime.length>100)throw Error('Archivo de actualización inválido');paths.add(f.path);total+=f.bytes;}
 if(total>1024*1024*1024||!paths.has('game.js')||!paths.has('game-entry147.html'))throw Error('Contenido incompleto');return m;
}
function wanted189(m){return m.files.filter(f=>!(C.bundledPaths||[]).includes(f.path));}
