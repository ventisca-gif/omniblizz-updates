async function install(){
 if(working||checking||!available||available.minShell>C.shell||!db)return;working=true;canceled=false;const m=available;status='Descargando '+m.version+'…';render();
 try{
  try{await navigator.storage?.persist?.();}catch{}
  const missing=new Map();for(const f of wanted189(m)){const saved=await get('files',f.sha256);if(!saved||saved.size!==f.bytes){if(!missing.has(f.pack))missing.set(f.pack,[]);missing.get(f.pack).push(f);}}
  const packs=m.packs.filter(p=>missing.has(p.sha256)),total=packs.reduce((n,p)=>n+p.bytes,0);let done=0;
  for(const p of packs){if(canceled)throw Error('Descarga cancelada');const data=await fetchBounded(p.url,p.bytes,n=>{progress=Math.min(100,Math.round((done+n)/Math.max(1,total)*100))+'% · '+size189(done+n)+' / '+size189(total);render();});
   if(data.byteLength!==p.bytes||await hash(data)!==p.sha256)throw Error('Un archivo está incompleto o no coincide.');
   for(const f of missing.get(p.sha256)){if(canceled)throw Error('Descarga cancelada');const b=data.slice(f.offset,f.offset+f.bytes);if(b.byteLength!==f.bytes||await hash(b)!==f.sha256)throw Error('Un archivo está incompleto o no coincide.');await put('files',f.sha256,new Blob([b],{type:f.mime}));}
   done+=p.bytes;progress=Math.round(done/Math.max(1,total)*100)+'% · '+size189(done)+' / '+size189(total);render();
  }
  config.candidate={manifest:m};config.trial=false;config.highest=Math.max(config.highest||0,m.revision);await saveConfig();status='Actualización verificada y lista. Guarda y reinicia para aplicarla.';available=null;progress='';
  if(firstBoot189){location.reload();return;}
 }catch(e){status='No se aplicó la actualización: '+(e.name==='QuotaExceededError'?'falta espacio en el teléfono.':e.message)+'. La versión anterior se conserva.';progress='';}
 finally{working=false;render();}
}
async function mount(){for(const f of wanted189(selected.manifest)){const blob=await get('files',f.sha256);if(!blob||blob.size!==f.bytes)throw Error('Falta un archivo descargado');urls.set(f.path,URL.createObjectURL(new Blob([blob],{type:f.mime})));}
 for(const f of wanted189(selected.manifest))if(f.path.endsWith('.css')){const blob=await get('files',f.sha256);URL.revokeObjectURL(urls.get(f.path));urls.set(f.path,URL.createObjectURL(new Blob([rewriteCSS(await blob.text(),new URL(f.path,baseURL).href)],{type:'text/css'})));}
 if(C.edition==='creator'){const f=selected.manifest.files.find(f=>f.path==='game.js'),blob=await get('files',f.sha256),program=window.OmniCreator189.buildGame(await blob.text());URL.revokeObjectURL(urls.get('game.js'));urls.set('game.js',URL.createObjectURL(new Blob([program],{type:'text/javascript'})));}
}
