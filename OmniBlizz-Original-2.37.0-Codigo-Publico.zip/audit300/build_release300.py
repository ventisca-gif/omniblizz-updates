from pathlib import Path
import zipfile,json,base64,hashlib,subprocess,tempfile,mimetypes
r=Path('/workspace/scratch/576b751c7e7e');out=r/'release300';out.mkdir(exist_ok=True);candidate=r/'audit300/candidate';oldout=r/'release299';sha=lambda b:hashlib.sha256(b).hexdigest();key=r/'private-signing297/update-signing.pem';pub=(r/'private-signing297/derived-public.pem').read_bytes()
resources={'game.js':(candidate/'game.js').read_bytes(),'game-entry147.html':(candidate/'game-entry147.html').read_bytes()}
notes=(candidate/'release-notes.md').read_text();manifests={}
with tempfile.TemporaryDirectory() as d:
 t=Path(d);(t/'pub').write_bytes(pub)
 for name in ['original-content-manifest.json','original-manifest.json']:
  env=json.loads((oldout/name).read_text());raw=base64.b64decode(env['payload']);(t/'payload').write_bytes(raw);(t/'sig').write_bytes(base64.b64decode(env['signature']));subprocess.run(['openssl','dgst','-sha256','-verify',str(t/'pub'),'-signature',str(t/'sig'),str(t/'payload')],check=True,capture_output=True);m=json.loads(raw);assert m['revision']==299;manifests[name]=m
pack=b''.join(resources.values());ph=sha(pack);(out/f'content-{ph}.bin').write_bytes(pack);url='https://github.com/ventisca-gif/omniblizz-updates/releases/download/v2.36.8/';files=[];offset=0
for name,data in resources.items():
 h=sha(data);(out/f'original-{h}.bin').write_bytes(data);files.append(dict(path=name,bytes=len(data),sha256=h,mime=mimetypes.guess_type(name)[0] or 'application/octet-stream',offset=offset,pack=ph));offset+=len(data)
for name,m in manifests.items():
 m['version']='2.36.8';m['revision']=300;m['notes']=notes
 if name=='original-content-manifest.json':
  m['files']=[f for f in m['files'] if f['path'] not in resources]+files;used={f['pack'] for f in m['files']};m['packs']=[p for p in m['packs'] if p['sha256'] in used]+[dict(sha256=ph,bytes=len(pack),url=url+f'content-{ph}.bin')];assert len(m['files'])==1597;assert {p['sha256'] for p in m['packs']}==used
 else:m['files']=[f for f in m['files'] if f['path'] not in resources]+[{k:v for k,v in f.items() if k not in ['offset','pack']}|dict(url=url+'original-'+f['sha256']+'.bin') for f in files]
 raw=json.dumps(m,ensure_ascii=False,separators=(',',':')).encode()
 with tempfile.TemporaryDirectory() as d:
  t=Path(d);(t/'payload').write_bytes(raw);(t/'pub').write_bytes(pub);sig=subprocess.check_output(['openssl','dgst','-sha256','-sign',str(key),str(t/'payload')]);(t/'sig').write_bytes(sig);subprocess.run(['openssl','dgst','-sha256','-verify',str(t/'pub'),'-signature',str(t/'sig'),str(t/'payload')],check=True,capture_output=True)
 (out/name).write_text(json.dumps(dict(payload=base64.b64encode(raw).decode(),signature=base64.b64encode(sig).decode()),separators=(',',':')))
(out/'release-notes.md').write_text(notes)
info=dict(version='2.36.8',revision=300,resources=1597,changed=list(resources),incrementalBytes=len(pack),checksPassed=516,signatureVerified=True,androidBenchmark=False,regressionFullyResolved=False);(out/'build-info.json').write_text(json.dumps(info,indent=2))
with zipfile.ZipFile(oldout/'OmniBlizz-Original-2.36.7-Codigo-Publico.zip') as zin,zipfile.ZipFile(out/'OmniBlizz-Original-2.36.8-Codigo-Publico.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in zin.namelist():
  data=resources.get(name.removeprefix('alienx280/public/')) if name.startswith('alienx280/public/') else None
  z.writestr(name,data if data is not None else zin.read(name))
 for p in (r/'audit300').rglob('*'):
  if p.is_file() and 'runtime' not in p.parts and 'windows-source' not in p.parts and p.name not in ['game.js','creator-game300.js','base188-creator.js']:z.write(p,'audit300/'+str(p.relative_to(r/'audit300')))
print(json.dumps(info))
