# OmniBlizz · 2.36.8 en preparación

Base pública: 2.36.7, revisión 299. Siguiente revisión: 300.

## Cambios

- Actualizador: se reproduce una oferta obsoleta de la versión ya activada cuando la comprobación termina durante la carga. El puente vuelve a comprobar después de contentReady189(). El cargador conserva firma, recuperación y selección de versión; no se reemplaza el shell.
- La entrada muestra un estado de carga hasta terminar la decoración actual, sin mostrar primero el diseño anterior; rótulos de versión corregidos.
- Prueba Prototipo desde el menú: iframe con estado y almacenamiento en memoria, sin partidas, IndexedDB, nube ni multijugador. Nivel 140, vitalidad Ten 25, entrenamiento completo y habilidades aprendidas. 26 formas del Prototipo, excluido Cuatro Brazos AF. Enemigos invocables con límite 12, recuperación y limpieza. Al salir se elimina la sesión.
- El minimapa antiguo deja de pintarse cuando su canvas está oculto. Conserva el dibujo visible, los retratos no Omnitrix y el atlas.

## Validación

411 comprobaciones heredadas más 81 de arranque/actualizador/aislamiento/configuración y 24 del minimapa; 516 en total. En navegador privado: las 26 formas se transformaron, se invocaron sus ataques y se ejecutó draw sin excepciones. Partida normal de prueba nivel 17: almacenamiento idéntico durante la prueba nivel 140 y tras salir; nivel 17 conservado después de recargar. Invocación comprobada. Mascotas llegó al final de su lista (44/44); Monturas también se desplazó. El control antiguo del minimapa estaba oculto.

El código qa-browser300.js es instrumentación de pruebas y no está insertado en game.js publicado. Los resultados de unidades usan entornos simulados y no sustituyen la ejecución completa. Se ha usado el motor Original; la adaptación Creator se comprueba separadamente. Falta Android físico y la partida afectada. No se afirma que la regresión completa esté resuelta ni que alcance 60 FPS.
