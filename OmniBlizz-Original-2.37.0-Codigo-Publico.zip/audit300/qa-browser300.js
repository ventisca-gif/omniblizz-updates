// Private browser harness. Not part of release game.js.
if(location.search.includes('qa300=1')||window.OmniTrialQA300){
 if(window.OmniTrial300){
  window.trialProof300={state:()=>({level:player.level,race,watch:player.equippedWatch73,ids:prototypeIds300(),stored:localStorage.getItem(STORE),ten:player.vitality}),all(){const rows=[];for(const id of prototypeIds300()){try{if(player.alien)revert(false);player.alien=false;player.selected=player.activeAlien=id;player.watchOpen=true;player.battery=omniCap53();player.lock=player.emptyLock=player.jump=0;player.motion=player.leap=null;paused=false;cinematic=null;nextRoll23=null;commitTransform();rows.push({id,active:player.activeAlien,alien:player.alien,ok:player.alien&&player.activeAlien===id});}catch(e){rows.push({id,error:String(e)});}}return rows;}};
 }else{
  let baseline300=null;const allStorage300=()=>JSON.stringify(Object.keys(localStorage).sort().map(k=>[k,localStorage.getItem(k)]));
  const out=document.createElement('pre');out.id='qa300-result';out.style.cssText='position:fixed;right:1%;top:30%;z-index:9800;background:#021b13;color:#deffa1;padding:8px;max-width:45%;max-height:45%;overflow:auto;font:12px monospace';document.body.append(out);
  const q=document.createElement('div');q.style.cssText='position:fixed;right:1%;top:24%;z-index:9801;display:flex;gap:4px';document.body.append(q);
  for(const [name,fn]of [['QA baseline',()=>{player.level=17;player.hp=maxHP();persistGame();baseline300=allStorage300();out.textContent=JSON.stringify({baseline:true,level:player.level});}],['QA inspect',()=>{const f=$('#trial-frame300');out.textContent=JSON.stringify({unchanged:baseline300===allStorage300(),normalLevel:player.level,child:f?.contentWindow.trialProof300?.state()},null,2);}],['QA all forms',()=>{out.textContent=JSON.stringify($('#trial-frame300')?.contentWindow.trialProof300?.all(),null,2);} ]]){const b=document.createElement('button');b.textContent=name;b.onclick=fn;q.append(b);}
 }
}
