const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const source=fs.readFileSync('diagnostics299/candidate-game.js','utf8');
assert(source.indexOf('const companionMenuBefore299=')<source.lastIndexOf('})();'),'Companion patch must be inside game scope');
const listeners={},moves=[],calls=[];let current=null,passed=0;
const list={dataset:{},scrollTop:200,clientHeight:160,offsetWidth:400,getBoundingClientRect:()=>({width:200}),addEventListener:(k,v)=>listeners[k]=v,scrollBy:o=>moves.push(o),hasPointerCapture:()=>false,setPointerCapture:()=>{}};
const c={$:()=>current,companionMenu289:k=>{calls.push(k);current=list;return k;},scrollPanel219:d=>calls.push('fallback'+d),document:{createElement:()=>({}),head:{append:()=>{}}}};
vm.createContext(c);const line=source.split('\n').find(l=>l.startsWith('function dragPanel223('));assert(line);vm.runInContext(line+'\n'+fs.readFileSync('diagnostics299/companions-scroll.js','utf8'),c);
for(const kind of ['ship','mount']){assert.equal(c.companionsMenu113(kind),kind);passed++;assert.equal(list.dataset.drag223,'1');passed++;for(const dir of [-1,1]){c.scrollPanel219(dir);assert.equal(moves.at(-1).top,dir*120);passed++;}}
current=null;c.scrollPanel219(1);assert.equal(calls.at(-1),'fallback1');passed++;
const target={closest:()=>null};listeners.pointerdown({button:0,target,pointerId:5,clientY:100});listeners.pointermove({pointerId:6,clientY:20});assert.equal(list.scrollTop,200);passed++;
listeners.pointermove({pointerId:5,clientY:60});assert.equal(list.scrollTop,280);passed++;
let cancelled=0;listeners.click({preventDefault:()=>cancelled++,stopImmediatePropagation:()=>cancelled++});assert.equal(cancelled,2);passed++;
listeners.pointerup({});listeners.pointermove({pointerId:5,clientY:10});assert.equal(list.scrollTop,280);passed++;
const css=vm.runInContext('companionCSS299.textContent',c);for(const token of ['#old289{width:100px!important;height:100px!important','overflow-y:auto','touch-action:none','flex-shrink:0']){assert(css.includes(token));passed++;}
console.log(JSON.stringify({passed,failed:0,scope:'Production gesture handler, list arrow routing for pets/mounts, click suppression after dragging and scoped CSS contracts. Visual Android layout remains unverified.'},null,2));
