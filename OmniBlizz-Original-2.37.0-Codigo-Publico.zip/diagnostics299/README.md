# Diagnóstico de FPS — SIN PUBLICAR

Petición vigente: investigar y no entregar otra actualización mientras siga sin resolverse la regresión. No se ha creado una release, firmado manifiestos nuevos ni cambiado el actualizador.

## Hallazgos reproducidos

- El controlador FPS, el reloj de renderizado, la selección de objetivo y el medidor son idénticos entre 2.28.0 y 2.36.6. El /30 de la captura indica objetivo 30; no demuestra por sí solo un error del medidor ni la causa de la ralentización.
- La caché nueva de texturas de expedición/vestuario expulsa recursos aún visibles al superar seis hojas. Secuencia de siete hojas por fotograma: 840 objetos Image en 120 fotogramas. El candidato conserva siete y retira recursos inactivos cuando envejecen. Esto prueba el fallo de la caché, no su presencia en la captura concreta.
- El HUD dibuja el holograma abierto aunque el dial esté cerrado. El candidato omite solo ese dibujo oculto.
- El reloj cerrado también se vuelve a pintar/copiar en cada HUD. El candidato conserva sus propios píxeles cuando no cambia y repinta al cambiar selección, forma, tamaño, recurso, raza o contexto. No copia otro canvas en cada refresco.
- Inventario sintético de 42 tipos: aumentar cantidades de 1 a 999.999 no aumentó el coste. No autoriza a descartar datos corruptos, otro número de tipos u otras partidas.

## Límites

Las capturas muestran prototipo/nivel 33 frente a recalibrado/nivel 250, distintos efectos y objetivos FPS. La matriz usa nivel 250, zona 1, calidad normal, objetivo 60, estados sintéticos iguales y funciones instrumentadas; no reproduce por completo la partida del usuario. Las auras pueden cargar de forma asíncrona: los resultados no certifican su coste estable tras cargar todos sus recursos. La CPU de este navegador no mide el hardware Android. No se promete recuperar 40–55 FPS ni eliminar todos los errores.

Pruebas: 27 caché, 24 dial oculto, 17 invalidación del reloj, más 326 comprobaciones previas = 411 (incluye 17 comprobaciones adicionales de Mascotas/Monturas). Pendiente: sesión prolongada con carga gráfica completa, matriz de razas/escenarios, multijugador con cosméticos distintos, APK/WebView y partida afectada.

Para reconstruir: python3 diagnostics299/patch-cache.py optimization298/game.js diagnostics299/candidate-game.js

## Política de caché comprobada

Se protegen las imágenes utilizadas en el fotograma actual y el anterior. Solo se expulsan recursos completos que dejan de usarse; no se usa un plazo fijo de dos segundos. En 3.600 fotogramas con un carrusel de 77 cosméticos, el máximo observado fue seis entradas; con siete hojas siempre visibles y un cosmético cambiante, nueve. Son pruebas de objetos y entradas, no mediciones de memoria gráfica decodificada.

La prueba sintética del HUD recalibrado pasó de una mediana de 2,92 ms a 0,72 ms por llamada. Esto no es una medición de FPS Android.

SHA-256 del candidato: db6daa31286cf22d988649a0bc295535e5ccbd15ea47f6a3a0036efd6ebe4a5e.

## Mascotas y Monturas

Corrección candidata: las flechas apuntan a la lista interior; se activa el controlador de arrastre existente en ella, se evita el segundo desplazamiento exterior y se limita el retrato antiguo a 100 × 100 píxeles CSS. El pie queda fuera de la lista. Las 17 pruebas comprueban rutas de ambas apps, escalado del gesto, supresión de clic después de arrastrar y contratos CSS. La validación visual en Android sigue pendiente.
