const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync(process.argv[2]||'audit298/candidate/game.js','utf8');
const statements=['const IM285=','const imageBefore287='].map(t=>{const p=source.indexOf(t);return source.slice(p,source.indexOf('\n',p));}).join('\n');
const keys=['mars-boy','mars-girl','mars-goop','mars-anodite','piscciss-boy','piscciss-girl','vfx'];
let made=0;const ctx={Image:class {constructor(){made++;this.complete=true;this.naturalWidth=1536;this.width=1536;this.height=2048;}},raidURL225:x=>x,REDESIGNED287:new Set(['mars-goop','mars-anodite']),portraitKey86:''};vm.createContext(ctx);vm.runInContext(statements,ctx);
const rows=[];for(const count of [5,6,7]){made=0;vm.runInContext('for(const k in IM285)delete IM285[k];imageLRU285.clear();',ctx);for(let frame=0;frame<120;frame++)for(const key of keys.slice(0,count))ctx.image285(key);rows.push({distinctVisibleImages:count,frames:120,imageObjectsCreated:made,minimumNeeded:count});}
console.log(JSON.stringify({scenario:'Round-robin visible source images, loaded successfully; production image285/image287 functions',results:rows},null,2));
