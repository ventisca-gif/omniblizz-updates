// One bounded list owns gestures and arrows; keep footer outside scrolling content.
const companionMenuBefore299=companionMenu289;
companionMenu289=function(...args){const out=companionMenuBefore299(...args);dragPanel223($('#dialogbody .companions289'));return out;};
companionsMenu113=companionMenu289;
const scrollPanelBefore299=scrollPanel219;
scrollPanel219=function(dir){const list=$('#dialogbody .companions289');if(!list)return scrollPanelBefore299(dir);list.scrollBy({top:dir*Math.max(80,list.clientHeight*.75),behavior:'smooth'});};
const companionCSS299=document.createElement('style');
companionCSS299.textContent=`.dialog:has(.companions289){display:flex!important;flex-direction:column!important;height:82%!important;max-height:92%!important;box-sizing:border-box}.dialog:has(.companions289)>#dialogbody{flex:1;min-height:0;overflow:hidden!important;max-height:none!important}.dialog:has(.companions289)>#scrollnav,.dialog:has(.companions289)>#dialogbuttons{flex-shrink:0}.companions289{height:100%;max-height:none;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;touch-action:none;box-sizing:border-box}.companions289 button{touch-action:none}.companions289 .card289{min-width:0;box-sizing:border-box}.companions289 .card289>div{min-width:0;flex:1}.companions289 h3,.companions289 p{overflow-wrap:anywhere}.companions289 #old289{width:100px!important;height:100px!important;max-width:32%!important;object-fit:contain;flex:0 0 100px;image-rendering:pixelated}.companions289 .icon289{max-width:32%;flex-shrink:0}`;
document.head.append(companionCSS299);
