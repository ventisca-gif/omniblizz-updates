const stableWatch299=new WeakMap();
const nativeWatch299=watchBefore294;
watchFace19=function(c,open,id){
 const cv=c.canvas;
 if(cv!==watchCanvas19||open||race!=='omni'||!recal115()||!image115.ui.complete||!image115.ui.naturalWidth){
  stableWatch299.delete(cv);return nativeWatch299(c,open,id);
 }
 const key=[cv.width,cv.height,player.alien,player.selected,player.activeAlien,id,player.equippedWatch73,image115.ui.src,image115.ui.naturalWidth].join('|');
 if(stableWatch299.get(cv)===key)return;
 const out=nativeWatch299(c,open,id);stableWatch299.set(cv,key);return out;
};
addEventListener('resize',()=>stableWatch299.delete(watchCanvas19));
watchCanvas19.addEventListener('contextrestored',()=>stableWatch299.delete(watchCanvas19));
