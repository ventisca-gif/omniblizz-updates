# OmniBlizz Original 2.36.7 · Rendimiento y compañeros

- Evita crear repetidamente imágenes que siguen visibles al superar seis hojas de sprites; retira las que dejan de usarse.
- Omite el holograma oculto cuando el dial está cerrado y conserva el dibujo del reloj recalibrado mientras no cambia su apariencia.
- Mascotas y Monturas: gestos y flechas desplazan la lista interior; retratos limitados y pie separado de la lista.
- Conserva objetos, progreso y contenido de la versión 2.36.6.

Validación: sintaxis y 411 comprobaciones automatizadas de cargador, simulación/HUD, comportamiento previo, caché, reloj y desplazamiento. Medición sintética de CPU del HUD recalibrado: mediana de 2,92 a 0,72 ms por llamada en navegador de nube. Esto no mide FPS Android. La mejora en el dispositivo y la partida afectada todavía debe comprobarse; no se declara resuelta toda la regresión.
