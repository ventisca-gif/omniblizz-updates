from pathlib import Path

def patch(s):
    helper='''// QA candidate: keep recently visible sheets resident instead of evicting them mid-scene.
const imageTouch299=new WeakMap();let imageFrame299=0;
function touchImage299(im){imageTouch299.set(im,imageFrame299);return im;}
function idleImage299(im){return im?.complete&&imageFrame299-(imageTouch299.get(im)??-Infinity)>1;}
'''
    marker='const IM285={},imageLRU285=new Map();'
    assert s.count(marker)==1
    s=s.replace(marker,helper+marker)
    changes=[
      ('imageLRU285.delete(k);imageLRU285.set(k,true);','touchImage299(IM285[k]);imageLRU285.delete(k);imageLRU285.set(k,true);'),
      ('key!==k&&IM285[key]?.complete','key!==k&&idleImage299(IM285[key])'),
      ("imageLRU285.delete(cacheKey);imageLRU285.set(cacheKey,true);","touchImage299(IM285[cacheKey]);imageLRU285.delete(cacheKey);imageLRU285.set(cacheKey,true);"),
      ('key!==cacheKey&&IM285[key]?.complete','key!==cacheKey&&idleImage299(IM285[key])'),
      ('wardrobeImages288.set(key,im);if(wardrobeImages288.size>6)', 'wardrobeImages288.set(key,im);}touchImage299(wardrobeImages288.get(key));if(wardrobeImages288.size>6)'),
      ('if(k!==key&&v.complete){wardrobeImages288.delete(k);break;}}}}return wardrobeImages288.get(key);','if(k!==key&&idleImage299(v)){wardrobeImages288.delete(k);break;}}}return wardrobeImages288.get(key);')
    ]
    for a,b in changes:
      assert s.count(a)==1,(a,s.count(a))
      s=s.replace(a,b)
    old="watchFace19(watchCanvas19.getContext('2d'),false,id);watchFace19($('#dialportrait').getContext('2d'),true,id);"
    assert s.count(old)==1
    s=s.replace(old,"watchFace19(watchCanvas19.getContext('2d'),false,id);if(open)watchFace19($('#dialportrait').getContext('2d'),true,id);")
    a=s.index('const watchCache294=');b=s.index('let layoutCache294=',a)
    s=s[:a]+'const watchBefore294=watchFace19;'+chr(10)+Path(__file__).with_name('stable-watch.js').read_text()+chr(10)+s[b:]
    marker='const simulateBefore297=simulate75;'
    assert s.count(marker)==1
    s=s.replace(marker,'const drawFrameBefore299=draw;draw=function(...a){imageFrame299++;return drawFrameBefore299(...a);};'+chr(10)+marker)
    marker="const drawFrameBefore299=draw;"
    assert s.count(marker)==1
    s=s.replace(marker,Path(__file__).with_name("companions-scroll.js").read_text()+chr(10)+marker)
    return s
if __name__=='__main__':
 import sys
 Path(sys.argv[2]).write_text(patch(Path(sys.argv[1]).read_text()))
