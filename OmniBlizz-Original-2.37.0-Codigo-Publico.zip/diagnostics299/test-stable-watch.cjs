const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const source=fs.readFileSync('diagnostics299/stable-watch.js','utf8');let passed=0;
function setup(){let paints=0;const events={},canvasEvents={};const cv={width:196,height:196,addEventListener:(n,f)=>canvasEvents[n]=f};const c={watchBefore294:()=>{paints++;return 'native';},watchCanvas19:cv,race:'omni',player:{alien:false,selected:'fasttrack',activeAlien:'fasttrack',equippedWatch73:'recalibrated115'},recal115:()=>c.player.equippedWatch73==='recalibrated115',image115:{ui:{complete:true,naturalWidth:1024,src:'ui.png'}},addEventListener:(n,f)=>events[n]=f};vm.createContext(c);vm.runInContext(source,c);return{c,cv,events,canvasEvents,paints:()=>paints,paint:(open=false,id='fasttrack',canvas=cv)=>c.watchFace19({canvas},open,id)};}
{const e=setup();for(let i=0;i<100;i++)e.paint();assert.equal(e.paints(),1);passed++;}
for(const [obj,key,value] of [['canvas','width',300],['canvas','height',300],['player','alien',true],['player','selected','goop'],['player','activeAlien','goop'],['ui','src','other.png'],['ui','naturalWidth',2048]]){const e=setup();e.paint();(obj==='canvas'?e.cv:obj==='player'?e.c.player:e.c.image115.ui)[key]=value;e.paint();assert.equal(e.paints(),2,key);passed++;}
{const e=setup();e.paint();e.paint(false,'goop');assert.equal(e.paints(),2);passed++;}
for(const kind of ['resize','contextrestored']){const e=setup();e.paint();(kind==='resize'?e.events:e.canvasEvents)[kind]();e.paint();assert.equal(e.paints(),2);passed++;}
for(const field of ['complete','naturalWidth']){const e=setup();e.c.image115.ui[field]=field==='complete'?false:0;e.paint();e.paint();e.c.image115.ui[field]=field==='complete'?true:1024;e.paint();e.paint();assert.equal(e.paints(),3);passed++;}
{const e=setup();e.paint();e.paint(true);e.paint(true);e.paint();assert.equal(e.paints(),4);passed++;}
{const e=setup();e.paint();e.c.race='osmo';e.paint();e.paint();e.c.race='omni';e.paint();e.paint();assert.equal(e.paints(),4);passed++;}
{const e=setup();e.paint();e.c.player.equippedWatch73='original';e.paint();e.c.player.equippedWatch73='recalibrated115';e.paint();assert.equal(e.paints(),3);passed++;}
{const e=setup();const other={width:200,height:200};for(let i=0;i<10;i++)e.paint(false,'fasttrack',other);assert.equal(e.paints(),10);passed++;}
console.log(JSON.stringify({passed,failed:0,scope:'Unchanged visible closed clock reuses its pixels; native rendering on open, selection/appearance/size/source changes, image readiness, race transitions and context restoration.'},null,2));
