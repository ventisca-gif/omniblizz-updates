// Original2.00.1: the decorative flower outlines must not trap Rojo on the starting bed.
let flowerMask208=null;
const maskBefore208=utBuildMask207;utBuildMask207=function(){const mask=maskBefore208();if(mask&&flowerMask208!==mask){for(let y=1000;y<=1150;y++)for(let x=330;x<=630;x++){const dx=(x-480)/150,dy=(y-1075)/75;if(dx*dx+dy*dy<=1)mask[y*2600+x]=1;}flowerMask208=mask;}return mask;};
if(location.search.includes('qa=1'))window.__v208={eval:s=>eval(s)};
