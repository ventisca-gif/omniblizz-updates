(()=>{
 'use strict';
 if(location.origin!=='https://omniblizz.local'||!window.chrome?.webview)return;
 const send=(type,extra={})=>chrome.webview.postMessage({type,lang:localStorage.getItem('omni-lang')||document.documentElement.lang||'es',...extra});
 document.addEventListener('keydown',e=>{if(e.code==='F11'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)send('fullscreen');}},true);
 let resume=null;
 window.OmniWindows={done(){const cb=resume;resume=null;cb?.();},save(){try{window.OmniUpdates147?.beforeRestart?.();}catch(e){console.warn(e);}}};
 window.OmniUpdates147={open(cb){resume=cb;send('updates');},gameReady(){send('gameReady');},inGame:()=>false,beforeRestart:()=>{}};
 if(!localStorage.getItem('omni-input184'))localStorage.setItem('omni-input184','pc');
 document.addEventListener('DOMContentLoaded',()=>{const style=document.createElement('style');style.textContent='html,body{overscroll-behavior:none}#rotate{display:none!important}';document.head.append(style);});
})();
