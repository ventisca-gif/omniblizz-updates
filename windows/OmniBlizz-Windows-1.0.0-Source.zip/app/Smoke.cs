using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
namespace OmniBlizz.Windows {
static class Smoke {
 public static int Run(){
  var root=Path.Combine(Path.GetTempPath(),"OmniBlizzSmoke-"+Guid.NewGuid());Directory.CreateDirectory(root);
  File.WriteAllText(Path.Combine(root,"index.html"),"<!doctype html><html><body style='background:#061719;color:#a4ff67;font:30px Arial'>OmniBlizz Windows · WebView2 test<script>localStorage.setItem('omni-smoke','ok');chrome.webview.postMessage({ready:localStorage.getItem('omni-smoke')==='ok',secure:isSecureContext});</script></body></html>");
  int result=1;var form=new Form{Width=1000,Height=650,Text="OmniBlizz Windows native smoke test"};var web=new WebView2{Dock=DockStyle.Fill};form.Controls.Add(web);var timer=new Timer{Interval=45000};timer.Tick+=(s,e)=>{File.WriteAllText("smoke-failure.txt","WebView2 startup timed out");form.Close();};timer.Start();
  form.Shown+=async(s,e)=>{try{var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(root,"user"));await web.EnsureCoreWebView2Async(env);web.CoreWebView2.SetVirtualHostNameToFolderMapping("omniblizz.local",root,CoreWebView2HostResourceAccessKind.DenyCors);web.CoreWebView2.WebMessageReceived+=async(sender,args)=>{if(args.Source!="https://omniblizz.local/index.html"||!args.WebMessageAsJson.Contains("true"))return;var test=await web.ExecuteScriptAsync("localStorage.getItem('omni-smoke')==='ok'&&isSecureContext");if(test!="true")return;result=0;File.WriteAllText("smoke-ok.txt","Native Windows WebView2 engine, virtual HTTPS origin, JavaScript, postMessage and persistent storage: PASS");timer.Stop();form.Close();};web.CoreWebView2.Navigate("https://omniblizz.local/index.html");}catch(Exception ex){File.WriteAllText("smoke-failure.txt",ex.ToString());timer.Stop();form.Close();}};
  Application.Run(form);try{Directory.Delete(root,true);}catch{}return result;
 }
}
}
