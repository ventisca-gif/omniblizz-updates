using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace OmniBlizz.Windows {
[DataContract] public class Envelope { [DataMember] public string payload; [DataMember] public string signature; }
[DataContract] public class Asset { [DataMember] public string path; [DataMember] public string sha256; [DataMember] public long bytes; [DataMember] public string pack; [DataMember] public long offset; }
[DataContract] public class Pack { [DataMember] public string sha256; [DataMember] public long bytes; [DataMember] public string url; }
[DataContract] public class Manifest { [DataMember] public string edition; [DataMember] public string version; [DataMember] public int revision; [DataMember] public int schema; [DataMember] public int minShell; [DataMember] public List<Asset> files; [DataMember] public List<Pack> packs; }
public static class Json {
 public static T Read<T>(byte[] b) { using(var s=new MemoryStream(b))return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(s); }
 public static byte[] Write<T>(T o) { using(var s=new MemoryStream()){new DataContractJsonSerializer(typeof(T)).WriteObject(s,o);return s.ToArray();} }
}
public sealed class Updater : IDisposable {
 public const string Channel="https://github.com/ventisca-gif/omniblizz-updates/releases/latest/download/original-content-manifest.json";
 public const string Origin="https://omniblizz.local";
 public const int ShellCompatibility=189;
 public readonly string Root;
 readonly HttpClient http;
 public byte[] LatestEnvelope {get;private set;}
 public Manifest Latest {get;private set;}
 public string Current {get {var p=Path.Combine(Root,"active.txt");if(!File.Exists(p))return null;var id=File.ReadAllText(p).Trim();if(!id.All(c=>char.IsDigit(c)||c=='-'||c=='.'))return null;var d=Path.Combine(Root,"content",id);return File.Exists(Path.Combine(d,"game-entry147.html"))?d:null;} }
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateHardLink(string path,string existing,IntPtr reserved);
 public Updater(string root,HttpMessageHandler handler=null) { Root=root;Directory.CreateDirectory(root);http=handler==null?new HttpClient():new HttpClient(handler);http.Timeout=TimeSpan.FromMinutes(5);http.DefaultRequestHeaders.UserAgent.ParseAdd("OmniBlizz-Windows/1.0.0"); }
 public static string Hash(Stream s) { using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant(); }
 public static string Hash(byte[] b) { using(var s=new MemoryStream(b))return Hash(s); }
 public static bool Digest(string s) {return s!=null&&s.Length==64&&s.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');}
 public static string SafePath(string root,string path) {
  if(string.IsNullOrWhiteSpace(path)||path.Length>220||path.Contains('\\')||path.Contains(':')||path.StartsWith("/")||path.Split('/').Any(p=>p==".."||p=="."||p.Length==0||p.EndsWith(".")||p.EndsWith(" ")||p.IndexOfAny(new[]{'*','?','"','<','>','|','\0'})>=0))throw new InvalidDataException("Unsafe content path");
  var full=Path.GetFullPath(Path.Combine(root,path.Replace('/',Path.DirectorySeparatorChar)));var prefix=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)+Path.DirectorySeparatorChar;if(!full.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Path traversal");return full;
 }
 public static bool AllowedUrl(string s) { Uri u;return Uri.TryCreate(s,UriKind.Absolute,out u)&&u.Scheme=="https"&&u.IsDefaultPort&&u.Host=="github.com"&&u.AbsolutePath.StartsWith("/ventisca-gif/omniblizz-updates/releases/download/",StringComparison.Ordinal)&&string.IsNullOrEmpty(u.UserInfo); }
 public static Manifest Verify(byte[] envelope) {
  if(envelope.Length>8*1024*1024)throw new InvalidDataException("Manifest too large");var e=Json.Read<Envelope>(envelope);var raw=Convert.FromBase64String(e.payload);var signature=Convert.FromBase64String(e.signature);
  using(var rsa=RSA.Create()){rsa.ImportParameters(new RSAParameters{Modulus=Convert.FromBase64String("r6n+M2i0Hp/fyY9+6tpvvopHpTRjW16np+BEfo/SAT648t2A8e0KQx9UHydIC2AlcccoNv9YdIC+MquTEzzSj7ppOgVYcMiw6e5H6jLY2J2inmDgcU4Ck6zwHRPj4gqTkQEN9OmgTT4if04BvRQ9i63gYBL/UjyCB8uid+CEo/VMgN3VgJM8w3mAcLgkVOUbHTh48M1visNaSP3HjFZoavoBlonRKWWwTQ1dmMyS6K/vU/v3xfnaQt95Am4TE6XQgyTniG1FkdVZVI2Yo1Rg3cDUZWWA96eq73/Xa2UJqqS7uo+SV4kslSUrm4gZKOE+/H1kK6A/FggMIUiS1uejWRyaYyRLDiGTmsR2NlvVhQOl9cjvZ5KaI9vvPu5/cakRK2S5z5e8Fu/Zg5B7dHQ0cWkKPpsXt3zTo8yXJE/0dTbIXga2v5vTtOHvu/LnUfFQJYvnu5WSAzOdd+fEUAG3/PNw7eUiK2u44IBVbTZrdtUKTYMz9DiR8Y3KIvHsqvCf"),Exponent=Convert.FromBase64String("AQAB")});if(!rsa.VerifyData(raw,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1))throw new CryptographicException("Invalid content signature");}
  var m=Json.Read<Manifest>(raw);Validate(m);return m;
 }
 public static void Validate(Manifest m) {
  if(m==null||m.edition!="original"||m.schema!=2||m.minShell>ShellCompatibility||m.revision<=0||string.IsNullOrEmpty(m.version)||m.files==null||m.files.Count>20000||m.files.Count<1||m.packs==null||m.packs.Count>10000)throw new InvalidDataException("Incompatible content manifest");
  var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var packs=new Dictionary<string,Pack>();long total=0;
  foreach(var p in m.packs){if(!Digest(p.sha256)||p.bytes<=0||p.bytes>128L*1024*1024||!AllowedUrl(p.url)||packs.ContainsKey(p.sha256))throw new InvalidDataException("Invalid pack");packs.Add(p.sha256,p);}
  foreach(var f in m.files){SafePath(Path.GetTempPath(),f.path);Pack p;if(!paths.Add(f.path)||!Digest(f.sha256)||f.bytes<0||f.bytes>1024L*1024*1024||!packs.TryGetValue(f.pack,out p)||f.offset<0||f.offset>p.bytes-f.bytes)throw new InvalidDataException("Invalid file");total+=f.bytes;}
  if(total>4L*1024*1024*1024||!paths.Contains("game-entry147.html")||!paths.Contains("game.js"))throw new InvalidDataException("Incomplete content");
 }
 public Manifest Installed {get {var d=Current;if(d==null)return null;try{return Verify(File.ReadAllBytes(Path.Combine(d,".signed-manifest.json")));}catch{return null;}}}
 public async Task<Manifest> CheckAsync(CancellationToken ct) {using(var response=await http.GetAsync(Channel,ct).ConfigureAwait(false)){response.EnsureSuccessStatusCode();var b=await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);ct.ThrowIfCancellationRequested();var m=Verify(b);var installed=Installed;if(installed!=null&&m.revision<installed.revision)throw new InvalidDataException("Older update rejected");LatestEnvelope=b;Latest=m;return m;}}
 static bool Matches(string path,Asset f){if(!File.Exists(path)||new FileInfo(path).Length!=f.bytes)return false;using(var s=File.OpenRead(path))return Hash(s)==f.sha256;}
 public long RequiredDownload(Manifest m){var current=Current;var prior=Installed;var known=prior==null?new Dictionary<string,Asset>():prior.files.ToDictionary(f=>f.path);return m.files.Where(f=>current==null||!known.ContainsKey(f.path)||known[f.path].sha256!=f.sha256||!File.Exists(SafePath(current,f.path))||new FileInfo(SafePath(current,f.path)).Length!=f.bytes).Select(f=>f.pack).Distinct().Sum(h=>m.packs.First(p=>p.sha256==h).bytes);}
 public async Task ApplyAsync(Action<string,long,long> progress,CancellationToken ct) {
  if(Latest==null||LatestEnvelope==null)throw new InvalidOperationException("Check updates first");var m=Verify(LatestEnvelope);var old=Current;var id=m.revision+"-"+DateTime.UtcNow.Ticks;var stage=Path.Combine(Root,"content",id);Directory.CreateDirectory(stage);var needed=new Dictionary<string,List<Asset>>();bool activated=false;
  try {
   // Stage on the same volume: unchanged files share disk blocks, saves live elsewhere.
   foreach(var f in m.files){ct.ThrowIfCancellationRequested();var dst=SafePath(stage,f.path);Directory.CreateDirectory(Path.GetDirectoryName(dst));var src=old==null?null:SafePath(old,f.path);if(src!=null&&Matches(src,f)){bool linked=false;try{linked=CreateHardLink(dst,src,IntPtr.Zero);}catch(DllNotFoundException){}catch(EntryPointNotFoundException){}if(!linked)File.Copy(src,dst);continue;}if(!needed.ContainsKey(f.pack))needed[f.pack]=new List<Asset>();needed[f.pack].Add(f);}
   var total=m.packs.Where(p=>needed.ContainsKey(p.sha256)).Sum(p=>p.bytes);long done=0;
   foreach(var pack in m.packs.Where(p=>needed.ContainsKey(p.sha256))) {
    ct.ThrowIfCancellationRequested();var tmp=Path.Combine(Root,"download.tmp");try {
     using(var res=await http.GetAsync(pack.url,HttpCompletionOption.ResponseHeadersRead,ct).ConfigureAwait(false)){res.EnsureSuccessStatusCode();using(var input=await res.Content.ReadAsStreamAsync().ConfigureAwait(false))using(var output=new FileStream(tmp,FileMode.Create,FileAccess.Write,FileShare.None,81920,true)){var buffer=new byte[81920];long count=0;int n;while((n=await input.ReadAsync(buffer,0,buffer.Length,ct).ConfigureAwait(false))>0){count+=n;if(count>pack.bytes)throw new InvalidDataException("Oversized content pack");await output.WriteAsync(buffer,0,n,ct).ConfigureAwait(false);progress?.Invoke(m.version,done+count,total);}if(count!=pack.bytes)throw new InvalidDataException("Incomplete content download");}}
     using(var stream=File.OpenRead(tmp)){if(Hash(stream)!=pack.sha256)throw new CryptographicException("Pack hash mismatch");foreach(var f in needed[pack.sha256]){stream.Position=f.offset;var dst=SafePath(stage,f.path);using(var output=File.Create(dst)){var b=new byte[81920];long remain=f.bytes;while(remain>0){ct.ThrowIfCancellationRequested();int n=stream.Read(b,0,(int)Math.Min(remain,b.Length));if(n==0)throw new EndOfStreamException();output.Write(b,0,n);remain-=n;}}if(!Matches(dst,f))throw new CryptographicException("File hash mismatch");}}
     done+=pack.bytes;
    }finally{if(File.Exists(tmp))File.Delete(tmp);}
   }
   File.WriteAllBytes(Path.Combine(stage,".signed-manifest.json"),LatestEnvelope);ct.ThrowIfCancellationRequested();
   // Backup pointer survives a crash; gameReady commits only after the engine boots.
   WriteAtomic(Path.Combine(Root,"pending.txt"),old==null?"":Path.GetFileName(old));WriteAtomic(Path.Combine(Root,"active.txt"),id);activated=true;
  } finally {if(!activated&&Directory.Exists(stage))Directory.Delete(stage,true);}
 }
 public void RecoverInterruptedBoot(){var p=Path.Combine(Root,"pending.txt");if(!File.Exists(p))return;var previous=File.ReadAllText(p).Trim();if(previous.Length>0&&previous.All(c=>char.IsDigit(c)||c=='-'||c=='.')&&Directory.Exists(Path.Combine(Root,"content",previous)))WriteAtomic(Path.Combine(Root,"active.txt"),previous);File.Delete(p);}
 public void ConfirmBoot(){var current=Current;if(current==null)return;var p=Path.Combine(Root,"pending.txt");if(File.Exists(p))File.Delete(p);foreach(var d in Directory.GetDirectories(Path.Combine(Root,"content")))if(!string.Equals(d,current,StringComparison.OrdinalIgnoreCase))try{Directory.Delete(d,true);}catch(IOException){} }
 static void WriteAtomic(string path,string text){var temp=path+".new";File.WriteAllText(temp,text);if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}
 public void Dispose(){http.Dispose();}
}
}
