using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
namespace OmniBlizz.Windows {
static class Program {
 [STAThread] static void Main(string[] args){
  ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
  if(args.Length>=2&&args[0]=="--test"){try{Tests.Run(args[1]);File.WriteAllText("test-ok.txt","31 updater checks passed");Environment.Exit(0);}catch(Exception ex){File.WriteAllText("test-failure.txt",ex.ToString());Environment.Exit(1);}return;}
  if(args.Contains("--smoke-test")){Application.EnableVisualStyles();Environment.Exit(Smoke.Run());return;}
  using(var mutex=new Mutex(false,"Local\\OmniBlizzOriginalWindows")){bool owned;try{owned=mutex.WaitOne(0);}catch(AbandonedMutexException){owned=true;}if(!owned){MessageBox.Show("OmniBlizz ya está abierto / already running.");return;}
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);try{Application.Run(new GameWindow());}catch(Exception e){MessageBox.Show(e.Message,"OmniBlizz",MessageBoxButtons.OK,MessageBoxIcon.Error);}finally{mutex.ReleaseMutex();}}
 }
}
public sealed class GameWindow:Form {
 readonly string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OmniBlizz","Windows");
 readonly Panel gameArea=new Panel{Dock=DockStyle.Fill};readonly Updater updater;WebView2 view;Panel welcome;Label status;ProgressBar progress;Button install,play,cancel;CancellationTokenSource operation;bool busy,closing,fullscreen;FormWindowState previousState;FormBorderStyle previousBorder;Rectangle previousBounds;
 string lang=CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
 static readonly JavaScriptSerializer serializer=new JavaScriptSerializer{MaxJsonLength=32*1024*1024};
 string T(string es,string en,string pt,string tr){return lang=="pt"?pt:lang=="tr"?tr:lang=="en"?en:es;}
 public GameWindow(){
  Text="OmniBlizz Original · Windows";MinimumSize=new Size(960,540);Size=new Size(1280,760);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(6,19,23);KeyPreview=true;AutoScaleMode=AutoScaleMode.Dpi;
  updater=new Updater(root);updater.RecoverInterruptedBoot();
  var menu=new MenuStrip{BackColor=Color.FromArgb(13,35,39),ForeColor=Color.White};
  AddMenu(menu,T("Jugar","Play","Jogar","Oyna"),async()=>await Launch());
  AddMenu(menu,T("Actualizaciones","Updates","Atualizações","Güncellemeler"),async()=>{if(view?.CoreWebView2!=null)await view.ExecuteScriptAsync("window.OmniUpdates147?.openFromGame?.()");else await UpdateContent(false);});
  AddMenu(menu,T("Exportar partida","Export save","Exportar jogo","Kaydı dışa aktar"),async()=>await ExportSave());
  AddMenu(menu,T("Importar partida","Import save","Importar jogo","Kaydı içe aktar"),async()=>await ImportSave());
  AddMenu(menu,"F11 · "+T("Pantalla completa","Fullscreen","Tela cheia","Tam ekran"),()=>{ToggleFullscreen();return Task.CompletedTask;});
  AddMenu(menu,"?",()=>{MessageBox.Show(T("WASD/flechas: mover. Usa Controles PC en Pausa para ver las teclas de cada raza. F11: pantalla completa. Tus partidas permanecen al actualizar.\n\nWindows 10 22H2/11 de 64 bits y Microsoft WebView2 Runtime.\nJuego online: requiere Internet. La conexión Wi-Fi nativa de la APK no está incluida en este lanzador.","WASD/arrows: move. Open PC Controls in Pause for each race's keys. F11: fullscreen. Saves persist across updates.\n\n64-bit Windows 10 22H2/11 and Microsoft WebView2 Runtime.\nOnline play requires Internet. The APK's native Wi-Fi bridge is not included.","WASD/setas: mover. Controles PC em Pausa mostra teclas por raça. F11: tela cheia. Saves preservados.\n\nWindows 10 22H2/11 de 64 bits e WebView2. Online requer Internet; ponte Wi-Fi nativa da APK não incluída.","WASD/oklar: hareket. Duraklat menüsünde PC Kontrolleri. F11: tam ekran. Kayıtlar güncellemede korunur.\n\n64 bit Windows 10 22H2/11 ve WebView2. Çevrimiçi oyun İnternet ister; APK yerel Wi-Fi köprüsü dahil değil."),"OmniBlizz Windows 1.0.0");return Task.CompletedTask;});
  MainMenuStrip=menu;var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=Padding.Empty,Padding=Padding.Empty};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));Controls.Add(layout);layout.Controls.Add(menu,0,0);layout.Controls.Add(gameArea,0,1);menu.Dock=DockStyle.Fill;
  welcome=new Panel{Dock=DockStyle.Fill,Padding=new Padding(50)};
  var title=new Label{Text="OMNIBLIZZ · WINDOWS",Font=new Font("Segoe UI",25,FontStyle.Bold),ForeColor=Color.FromArgb(156,245,79),Dock=DockStyle.Top,Height=70};
  status=new Label{Text=T("Instala el contenido del juego para comenzar. La APK Android es independiente.","Install the game content to start. The Android APK is separate.","Instale o conteúdo para começar. A APK Android é separada.","Başlamak için oyun içeriğini kur. Android APK ayrıdır."),Dock=DockStyle.Top,Height=100,ForeColor=Color.White,Font=new Font("Segoe UI",12)};
  progress=new ProgressBar{Dock=DockStyle.Top,Height=24};var buttons=new FlowLayoutPanel{Dock=DockStyle.Top,Height=64};
  install=new Button{Text=T("Instalar / actualizar","Install / update","Instalar / atualizar","Kur / güncelle"),Width=220,Height=44};install.Click+=async(s,e)=>await UpdateContent(false);
  play=new Button{Text=T("Jugar instalado","Play installed","Jogar instalado","Kurulu oyunu oyna"),Width=200,Height=44,Enabled=updater.Current!=null};play.Click+=async(s,e)=>await Launch();
  cancel=new Button{Text=T("Cancelar","Cancel","Cancelar","İptal"),Width=120,Height=44,Enabled=false};cancel.Click+=(s,e)=>operation?.Cancel();buttons.Controls.AddRange(new Control[]{install,play,cancel});
  welcome.Controls.Add(buttons);welcome.Controls.Add(progress);welcome.Controls.Add(status);welcome.Controls.Add(title);gameArea.Controls.Add(welcome);welcome.BringToFront();menu.BringToFront();
  Shown+=async(s,e)=>{if(updater.Current!=null)await Launch();else await UpdateContent(true);};
  FormClosing+=OnClosing;KeyDown+=(s,e)=>{if(e.KeyCode==Keys.F11&&(view==null||!view.ContainsFocus)){e.SuppressKeyPress=true;ToggleFullscreen();}};
 }
 void AddMenu(MenuStrip m,string name,Func<Task> f){var b=new ToolStripMenuItem(name);b.Click+=async(s,e)=>{if(busy)return;try{await f();}catch(Exception ex){ShowError(ex);}};m.Items.Add(b);}
 void ShowError(Exception e){status.Text=e.Message;MessageBox.Show(e.Message+T("\nLa instalación anterior y tus partidas se conservan.","\nYour previous installation and saves are preserved.","\nA instalação anterior e os saves são preservados.","\nÖnceki kurulum ve kayıtlar korunur."),"OmniBlizz",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 async Task UpdateContent(bool initial){
  if(busy)return;busy=true;install.Enabled=play.Enabled=false;cancel.Enabled=true;operation=new CancellationTokenSource();var ct=operation.Token;
  bool wasVisible=view!=null&&view.Visible;if(view!=null)view.Visible=false;welcome.Visible=true;welcome.BringToFront();MainMenuStrip.BringToFront();
  try {
   status.Text=T("Buscando contenido firmado…","Checking signed content…","Verificando conteúdo assinado…","İmzalı içerik denetleniyor…");
   var m=await Task.Run(()=>updater.CheckAsync(ct));var installed=updater.Installed;
   if(installed!=null&&installed.revision==m.revision){status.Text=T("Ya tienes la versión ","You have version ","Você já tem a versão ","Sürüm güncel: ")+m.version;return;}
   var bytes=updater.RequiredDownload(m);var message=T("Versión ","Version ","Versão ","Sürüm ")+m.version+"\n"+T("Descarga aproximada: ","Approximate download: ","Download aproximado: ","Yaklaşık indirme: ")+(bytes/1000000.0).ToString("0.0")+" MB\n"+T("Contenido instalado: ","Installed content: ","Conteúdo instalado: ","Kurulu içerik: ")+(m.files.Sum(f=>f.bytes)/1000000.0).ToString("0.0")+" MB\n\n"+T("¿Descargar ahora?","Download now?","Baixar agora?","Şimdi indirilsin mi?");
   if(MessageBox.Show(message,"OmniBlizz",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
   if(view!=null){await SaveNow();view.Dispose();view=null;wasVisible=false;}
   var report=new Progress<Tuple<string,long,long>>(p=>{status.Text=T("Descargando ","Downloading ","Baixando ","İndiriliyor ")+p.Item1+" · "+(p.Item2/1000000.0).ToString("0.0")+" / "+(p.Item3/1000000.0).ToString("0.0")+" MB";progress.Value=p.Item3<=0?0:(int)Math.Min(100,100.0*p.Item2/p.Item3);});
   await Task.Run(()=>updater.ApplyAsync((v,d,t)=>((IProgress<Tuple<string,long,long>>)report).Report(Tuple.Create(v,d,t)),ct));
   status.Text=T("Contenido verificado. Iniciando…","Content verified. Starting…","Conteúdo verificado. Iniciando…","İçerik doğrulandı. Başlatılıyor…");
  }catch(OperationCanceledException){status.Text=T("Descarga cancelada. Puedes reintentar.","Download canceled. You can retry.","Download cancelado. Tente novamente.","İndirme iptal edildi. Yeniden deneyebilirsin.");}catch(Exception e){ShowError(e);}finally{busy=false;install.Enabled=true;play.Enabled=updater.Current!=null;cancel.Enabled=false;operation.Dispose();operation=null;if(wasVisible&&view!=null){view.Visible=true;welcome.Visible=false;}if(view!=null)await view.ExecuteScriptAsync("window.OmniWindows?.done()");}
  if(updater.Current!=null&&view==null)await Launch();
 }
 async Task Launch(){
  if(busy||closing)return;if(updater.Current==null)return;if(view!=null){welcome.Visible=false;view.Visible=true;view.Focus();return;}
  try {
   CoreWebView2Environment.GetAvailableBrowserVersionString();
   view=new WebView2{Dock=DockStyle.Fill,DefaultBackgroundColor=Color.FromArgb(6,19,23)};gameArea.Controls.Add(view);view.BringToFront();MainMenuStrip.BringToFront();
   var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(root,"UserData"),new CoreWebView2EnvironmentOptions("--disk-cache-size=33554432 --media-cache-size=16777216"));await view.EnsureCoreWebView2Async(env);
   var core=view.CoreWebView2;core.Settings.AreDefaultContextMenusEnabled=false;core.Settings.AreDevToolsEnabled=false;core.Settings.IsStatusBarEnabled=false;core.Settings.AreBrowserAcceleratorKeysEnabled=false;core.Settings.IsZoomControlEnabled=false;core.Settings.AreHostObjectsAllowed=false;
   core.SetVirtualHostNameToFolderMapping("omniblizz.local",updater.Current,CoreWebView2HostResourceAccessKind.DenyCors);
   string script;using(var stream=typeof(GameWindow).Assembly.GetManifestResourceStream("bridge.js"))using(var reader=new StreamReader(stream))script=reader.ReadToEnd();await core.AddScriptToExecuteOnDocumentCreatedAsync(script);
   core.NavigationStarting+=(s,e)=>{Uri u;if(!Uri.TryCreate(e.Uri,UriKind.Absolute,out u)||u.Scheme!="https"||u.Host!="omniblizz.local")e.Cancel=true;};
   core.NewWindowRequested+=(s,e)=>{e.Handled=true;};
   core.PermissionRequested+=(s,e)=>{e.State=CoreWebView2PermissionState.Deny;};
   core.WebMessageReceived+=async(s,e)=>{if(!e.Source.StartsWith(Updater.Origin+"/",StringComparison.Ordinal))return;try{var msg=serializer.DeserializeObject(e.WebMessageAsJson) as System.Collections.Generic.Dictionary<string,object>;if(msg==null||!msg.ContainsKey("type"))return;var type=Convert.ToString(msg["type"]);if(msg.ContainsKey("lang")){var l=Convert.ToString(msg["lang"]).Substring(0,Math.Min(2,Convert.ToString(msg["lang"]).Length));if(new[]{"es","en","pt","tr"}.Contains(l))lang=l;}if(type=="fullscreen"){ToggleFullscreen();}else if(type=="gameReady"){updater.ConfirmBoot();Text="OmniBlizz Original "+updater.Installed?.version+" · Windows";}else if(type=="updates")await UpdateContent(false);}catch(Exception ex){ShowError(ex);}};
   core.ProcessFailed+=(s,e)=>{status.Text=T("El motor se cerró. Reinicia OmniBlizz.","The engine stopped. Restart OmniBlizz.","O motor parou. Reinicie OmniBlizz.","Motor durdu. OmniBlizz'i yeniden başlat.");welcome.Visible=true;welcome.BringToFront();MainMenuStrip.BringToFront();};
   welcome.Visible=false;core.Navigate(Updater.Origin+"/game-entry147.html");view.Focus();
  }catch(WebView2RuntimeNotFoundException){if(view!=null){view.Dispose();view=null;}welcome.Visible=true;status.Text=T("Instala Microsoft Edge WebView2 Runtime y vuelve a abrir OmniBlizz.","Install Microsoft Edge WebView2 Runtime, then reopen OmniBlizz.","Instale o Microsoft Edge WebView2 Runtime e reabra OmniBlizz.","Microsoft Edge WebView2 Runtime kurup OmniBlizz'i yeniden aç.");if(MessageBox.Show(status.Text+"\nhttps://developer.microsoft.com/microsoft-edge/webview2/","WebView2",MessageBoxButtons.OKCancel)==DialogResult.OK)Process.Start(new ProcessStartInfo("https://developer.microsoft.com/microsoft-edge/webview2/"){UseShellExecute=true});}
  catch(Exception e){if(view!=null){view.Dispose();view=null;}ShowError(e);welcome.Visible=true;}
 }
 void ToggleFullscreen(){if(!fullscreen){previousState=WindowState;previousBorder=FormBorderStyle;previousBounds=Bounds;WindowState=FormWindowState.Normal;FormBorderStyle=FormBorderStyle.None;Bounds=Screen.FromControl(this).Bounds;MainMenuStrip.Visible=false;fullscreen=true;}else{FormBorderStyle=previousBorder;Bounds=previousBounds;WindowState=previousState;MainMenuStrip.Visible=true;fullscreen=false;}}
 async Task SaveNow(){if(view?.CoreWebView2!=null)await view.ExecuteScriptAsync("window.OmniWindows?.save()");}
 async Task<string> SaveJson(){await SaveNow();var raw=await view.ExecuteScriptAsync("JSON.stringify(Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('omni')).map(k=>[k,localStorage.getItem(k)])))");return serializer.Deserialize<string>(raw);}
 async Task ExportSave(){if(view==null)return;using(var dialog=new SaveFileDialog{Filter="OmniBlizz Windows (*.json)|*.json",FileName="OmniBlizz-partida-"+DateTime.Now.ToString("yyyyMMdd-HHmm")+".json"})if(dialog.ShowDialog()==DialogResult.OK)File.WriteAllText(dialog.FileName,await SaveJson(),new UTF8Encoding(false));}
 async Task ImportSave(){if(view==null)return;using(var dialog=new OpenFileDialog{Filter="OmniBlizz Windows (*.json)|*.json"}){if(dialog.ShowDialog()!=DialogResult.OK)return;if(new FileInfo(dialog.FileName).Length>20*1024*1024)throw new InvalidDataException("Backup too large");var data=serializer.DeserializeObject(File.ReadAllText(dialog.FileName)) as System.Collections.Generic.Dictionary<string,object>;if(data==null||data.Count==0||data.Any(k=>!k.Key.StartsWith("omni",StringComparison.Ordinal)||!(k.Value is string)))throw new InvalidDataException(T("Usa un respaldo exportado desde Windows. Para Android, usa el respaldo del juego.","Use a Windows-exported backup. For Android, use the game's own backup.","Use backup exportado no Windows. Para Android, use o backup do jogo.","Windows yedeği kullan. Android için oyun içi yedeği kullan."));if(MessageBox.Show(T("¿Restaurar esta partida? Se guardará una copia de la actual.","Restore this save? A copy of your current save will be kept.","Restaurar? Uma cópia atual será guardada.","Bu kayıt yüklensin mi? Şimdiki kayıt yedeklenecek."),"OmniBlizz",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;var backups=Path.Combine(root,"Backups");Directory.CreateDirectory(backups);File.WriteAllText(Path.Combine(backups,"before-import-"+DateTime.UtcNow.Ticks+".json"),await SaveJson());await view.ExecuteScriptAsync("(()=>{const data="+serializer.Serialize(data)+";for(const [k,v] of Object.entries(data))localStorage.setItem(k,v);location.reload();})()");}}
 async void OnClosing(object sender,FormClosingEventArgs e){if(closing)return;e.Cancel=true;if(busy){operation?.Cancel();return;}closing=true;try{await SaveNow();}catch{}view?.Dispose();updater.Dispose();Close();}
}
}