OMNIBLIZZ ORIGINAL — WINDOWS 1.0.0 (x64)

ESPAÑOL
1. Extrae TODO el ZIP en una carpeta y abre OmniBlizz.exe. No abras la APK.
2. Windows 10 22H2 o Windows 11 de 64 bits, .NET Framework 4.8 y Microsoft Edge WebView2 Runtime. Si falta WebView2, el lanzador abre la página oficial de Microsoft para instalarlo.
3. La primera vez acepta descargar el contenido Original firmado. Versión inicial 2.27.1: 657 MB de descarga, 515 MB de archivos instalados (algunos paquetes incluyen archivos históricos). El lanzador ocupa cerca de 1 MB aparte. No incluye Chromium ni duplica la APK.
4. Jugar instalado funciona sin Internet. Para juego online y descargar actualizaciones sí se necesita Internet.
5. Actualiza desde Actualizaciones en la barra superior o desde la app del teléfono dentro del juego. Descarga solo los paquetes que contienen archivos nuevos/cambiados. Una actualización nunca se aplica en medio de la partida: primero se guarda y se reinicia el motor.
6. Mover: WASD o flechas. Pausa > Controles PC muestra las teclas de cada raza. F11 cambia pantalla completa. Se conserva la opción de cambiar PC/Android en Ajustes del juego.
7. Exportar/Importar partida en la barra superior maneja respaldos Windows. Para pasar desde Android, usa la opción de respaldo/código del propio juego; esta versión no copia automáticamente los datos del teléfono.
8. Datos: %LOCALAPPDATA%\OmniBlizz\Windows. No borres UserData si quieres conservar las partidas. Al importar un respaldo Windows se guarda una copia anterior en Backups.
9. Incluye juego solo y cliente online existente. El puente Wi-Fi local nativo de Android (OmniLAN) no está incluido. No se ha probado una partida multijugador real entre dispositivos.
10. El contenido usa las mismas firmas RSA/SHA-256 del actualizador Android. El ejecutable Windows no tiene certificado Authenticode comercial.
No borres las DLL junto a OmniBlizz.exe. No hace falta ejecutar como administrador. Para borrar solo el programa, elimina su carpeta; los guardados permanecen aparte.

ENGLISH
Extract the whole ZIP and run OmniBlizz.exe on 64-bit Windows 10 22H2/11. Requires .NET Framework 4.8 and Microsoft Edge WebView2 Runtime; a missing Runtime opens Microsoft's official download page. First launch downloads verified Original content (~657 MB download, ~515 MB installed). Launcher ~1 MB, Android APK remains separate. Installed solo content works offline. Updates use the same signed channel and only changed packs; saves are kept under %LOCALAPPDATA%\OmniBlizz\Windows\UserData. F11 fullscreen, WASD/arrows move; Pause > PC Controls lists all keys. Export/import Windows saves from the menu; Android transfer uses the game's own backup. Existing online client included; Android-native Wi-Fi bridge not included. Windows executable has no commercial Authenticode certificate.

PORTUGUÊS
Extraia o ZIP inteiro e abra OmniBlizz.exe no Windows 10 22H2/11 de 64 bits. Requer .NET Framework 4.8 e WebView2 Runtime. Na primeira vez baixa conteúdo Original verificado (~657 MB; instalado ~515 MB). Lançador ~1 MB, APK separada. Jogo solo instalado funciona offline. Atualizações pelo mesmo canal assinado, somente pacotes alterados; saves preservados em %LOCALAPPDATA%\OmniBlizz\Windows\UserData. F11 tela cheia; WASD/setas; Pausa > Controles PC. Menu exporta/importa backups Windows; Android usa backup do próprio jogo. Cliente online existente incluído, ponte Wi-Fi nativa Android não incluída. Executável sem certificado Authenticode comercial.

TÜRKÇE
ZIP'in tamamını çıkar ve 64 bit Windows 10 22H2/11 üzerinde OmniBlizz.exe aç. .NET Framework 4.8 ve WebView2 Runtime gerekir. İlk açılış doğrulanmış Original içeriği indirir (~657 MB indirme, ~515 MB kurulu). Başlatıcı ~1 MB; Android APK ayrıdır. Kurulu tek oyuncu çevrimdışı çalışır. Güncellemeler aynı imzalı kanaldan yalnızca değişen paketleri indirir; kayıtlar %LOCALAPPDATA%\OmniBlizz\Windows\UserData altında korunur. F11 tam ekran; WASD/oklar; Duraklat > PC Kontrolleri. Windows yedeklerini menüden aktar; Android için oyun içi yedek kullan. Mevcut çevrimiçi istemci dahil, Android yerel Wi-Fi köprüsü dahil değil. Ticari Authenticode sertifikası yok.
