from pathlib import Path
root=Path(__file__).resolve().parent
s=Path('work308/candidate/game.js').read_text()
old="const routeBefore307=routeGuide78;routeGuide78=function(){const d=Object.values(defs307).find(d=>d.id===player.guide78);if(!d)return routeBefore307();"
new="// Feed expansion destinations through the native path planner; drawRoute80 requires a path.\nconst targetBefore307=target80;target80=function(){const d=Object.values(defs307).find(d=>d.id===player.guide78);if(!d)return targetBefore307();"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("if(zone===d.zone)return {...d.npc,label:d.name};","if(zone===d.zone)return {...d.npc,label:d.name,arrival:'npc'};")
old="if(!t||t.manual||t.unreachable||t.blocked)return;ctx.strokeStyle='#bfff5d';"
new="if(!t||t.manual||t.unreachable||t.blocked||!Array.isArray(t.path))return;ctx.strokeStyle='#bfff5d';"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('2.41.1','2.41.2')
(root/'candidate/game.js').write_text(s)
h=Path('work308/candidate/game-entry147.html').read_text().replace('2.41.1','2.41.2').replace('v=308','v=309')
(root/'candidate/game-entry147.html').write_text(h)
