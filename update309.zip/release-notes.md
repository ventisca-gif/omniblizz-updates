OmniBlizz Original 2.41.2 · Corrección del bloqueo de TP

- Corregida la ruta de minas y Vulkanus que detenía el renderizado (0 FPS), incluso con una flecha guardada en el distrito nocturno.
- Los destinos nuevos vuelven a usar el planificador de rutas nativo. Protección de dibujo ante una ruta incompleta.
- Probados los 19 TP de misiones, aviso de entrada, movimiento y fotogramas después de viajar.
- Mantiene progreso, idiomas y Vulkanus con 3500 de daño.

ES: Corrige pantalla congelada al viajar o seguir minas/Vulkanus.
EN: Fixes frozen screen when travelling to or tracking mines/Vulkanus.
PT: Corrige a tela congelada ao viajar ou seguir minas/Vulkanus.
TR: Madenlere/Vulkanus’a yolculukta veya takipte ekran donması düzeltildi.
