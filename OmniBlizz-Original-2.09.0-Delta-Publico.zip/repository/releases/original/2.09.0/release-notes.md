OmniBlizz Original 2.09.0

Original 2.09.0: reference-inspired illustrated metallic main, pause and entry menus, bundled pixel font and static frame texture. Fixed invisible custom canvas avatars with alpha-bound portraits. Complete panels scroll by touch while every original action, recovery and language controller is retained. Four racial pause palettes. No combat or progression changes. ES/EN/PT/TR.
