"""Run manually in the owner's GitHub Codespace for omniblizz-updates."""
from pathlib import Path
import hashlib, json, subprocess, sys

EXPECTED = '4c4d68bad756b3739abd7261f3afbf48b875fc02'
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
def stop(message):
    sys.exit(message)

bundle = Path(__file__).resolve().parent
repo = Path(git('rev-parse', '--show-toplevel'))
remote = git('remote', 'get-url', 'origin')
if not any(s in remote.lower() for s in ['github.com/ventisca-gif/omniblizz-updates', 'github.com:ventisca-gif/omniblizz-updates']):
    stop('Abre un Codespace de ventisca-gif/omniblizz-updates antes de continuar.')
if git('branch', '--show-current') != 'main':
    stop('Selecciona main en un Codespace limpio antes de continuar.')
if git('diff', '--name-only') or git('diff', '--cached', '--name-only'):
    stop('Hay cambios previos. Usa un Codespace limpio para no mezclarlos.')
subprocess.run(['git', 'fetch', 'origin', 'main'], check=True)
if git('rev-parse', 'HEAD') != EXPECTED or git('rev-parse', 'origin/main') != EXPECTED:
    stop('main ha cambiado desde la preparacion. No se ha modificado ningun archivo; hay que revisar el paquete.')
hashes = json.loads((bundle / 'files-sha256.json').read_text())
for name, digest in hashes.items():
    p = Path(name)
    if p.is_absolute() or '..' in p.parts or not name.startswith(('build-tools/', '.github/workflows/', 'releases/original/1.92.0/', 'releases/original/1.93.0/', 'releases/original/1.94.0/')):
        stop('Ruta inesperada en el paquete.')
    data = (bundle / 'repository' / name).read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        stop('Paquete alterado o incompleto: ' + name)
for name in hashes:
    dest = repo / name
    if dest.is_symlink() or any(p.is_symlink() for p in dest.parents if p != repo.parent):
        stop('Ruta con enlace simbolico: ' + name)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((bundle / 'repository' / name).read_bytes())
subprocess.run(['git', 'add', '--', *hashes], check=True)
staged = set(git('diff', '--cached', '--name-only').splitlines())
if not staged or not staged.issubset(hashes):
    stop('Revisa los archivos preparados antes de publicar.')
subprocess.run(['git', 'commit', '-m', 'Release Original 1.94: floor access, Highbreed portraits and Fasttrack movie'], check=True)
subprocess.run(['git', 'push', 'origin', 'HEAD:main'], check=True)
print('\nArchivos enviados. GitHub Actions debe construir y publicar Original 1.94.')
print('Comprueba ambos procesos: https://github.com/ventisca-gif/omniblizz-updates/actions')
print('Solo cuando terminen correctamente comprueba la version v1.94.0 en Releases.')
