OmniBlizz Original 2.04.2

Cuatro Brazos AF ya tiene Dominio de combate independiente, EXP y bonificaciones. La barra de Anodita ahora está arriba, debajo del maná. Progreso existente conservado.

Original 2.04.2: Four Arms AF now has independent Combat Mastery, EXP and level bonuses. Anodite mastery bar moved up below the mana panel to clear the play area. Existing saves and other forms are preserved.
