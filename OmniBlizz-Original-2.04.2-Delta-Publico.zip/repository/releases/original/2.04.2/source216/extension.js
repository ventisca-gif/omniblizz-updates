// Original 2.04.2: Four Arms AF mastery registration and higher Anodite HUD.
if(ALIENS[FOUR187]&&!domainCatalog214.omni.includes('omni:'+FOUR187))domainCatalog214.omni.push('omni:'+FOUR187);
const domainLayoutBefore216=domainLayout215;
domainLayout215=function(){domainLayoutBefore216();if(race!=='anodite')return;const b=domainHUD215,p=$('.panel.omni');const width=Math.min(234,Math.max(160,W-24));Object.assign(b.style,{left:Math.max(12,W-width-12)+'px',top:Math.max(8,(p?p.offsetTop+p.offsetHeight:108)+8)+'px',width:width+'px'});};
domainLayoutKey215='';
if(location.search.includes('qa=1'))window.__v216={eval:s=>eval(s)};
