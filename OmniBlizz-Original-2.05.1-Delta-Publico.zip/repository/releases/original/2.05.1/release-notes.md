OmniBlizz Original 2.05.1

Original 2.05.1: removes the maximum Combat Mastery test button and its direct level grant from every edition. Normal mastery progression, earned Alien points and saved progress are preserved.
