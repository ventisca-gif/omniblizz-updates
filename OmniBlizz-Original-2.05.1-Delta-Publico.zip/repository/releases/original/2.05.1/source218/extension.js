// Original 2.05.1: remove the maximum-mastery test grant from every edition.
