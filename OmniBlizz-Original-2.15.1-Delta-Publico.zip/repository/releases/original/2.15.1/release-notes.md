OmniBlizz Original 2.15.1

Original 2.15.1: hotfix mission dialogs after Omnipedia, Drops and Crafting. Clear prior archive classes when opening each dialog and scope archive-only CSS to its actual content. Restores mission titles and Accept, Claim, Repeat and Close buttons while preserving quest progress, level/proximity checks and rewards. ES/EN/PT/TR.
