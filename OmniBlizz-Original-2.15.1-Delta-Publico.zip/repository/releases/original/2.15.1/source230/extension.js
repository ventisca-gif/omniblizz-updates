// Original 2.15.1: isolate full-screen archive styles from subsequent mission dialogs.
const dialogBefore230=showDialog;
showDialog=function(...args){
 const d=$('.dialog');
 // Every ordinary dialog must start without the previous archive's chrome.
 d?.classList.remove('pedia-dialog228','guide-dialog229');
 return dialogBefore230(...args);
};
// Also scope the rules to their real content, including legacy dialogs that replace body nodes.
for(const style of [pediaStyle228,style229]){
 style.textContent=style.textContent.replaceAll('.pedia-dialog228','.pedia-dialog228:has(#pedia228)').replaceAll('.guide-dialog229','.guide-dialog229:has(#guide229)');
}
if(location.search.includes('qa=1'))window.__dialogs230={eval:s=>eval(s)};
