OmniBlizz Original 2.06.0

Original 2.06.0: illustrated inventory, rare and epic timed XP smoothies, combat mastery smoothies, scrap crafting, equippable level ranks, detailed mission journal and same-race online rooms for Saiyan, Pokemon and Rojo. Normal progression and saves preserved.
